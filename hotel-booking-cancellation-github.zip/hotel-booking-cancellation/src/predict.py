"""Inference helpers shared by the Streamlit app and the notebook.

Keeping this logic out of `app.py` means it can be tested without Streamlit.
"""
from __future__ import annotations

import json
from dataclasses import dataclass

import joblib
import pandas as pd

from . import config as cfg
# Importing add_features makes sure the function referenced inside the saved
# pipeline can be found when joblib loads the model.
from .features import add_features  # noqa: F401

DEFAULT_THRESHOLD = 0.5


def load_model(path=cfg.MODEL_PATH):
    """Load the saved scikit-learn pipeline."""
    if not path.exists():
        raise FileNotFoundError(
            f"Model file not found: {path}\n"
            "Train it first with:  python -m src.train"
        )
    return joblib.load(path)


def load_metadata(path=cfg.METADATA_PATH) -> dict:
    """Load the JSON file written by the training script."""
    if not path.exists():
        raise FileNotFoundError(
            f"Metadata file not found: {path}\n"
            "Train the model first with:  python -m src.train"
        )
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def validate_booking(b: dict) -> list[str]:
    """Return a list of human-readable problems with the booking (empty = valid)."""
    problems = []
    missing = [c for c in cfg.RAW_FEATURES if b.get(c) in (None, "")]
    if missing:
        problems.append(f"Missing values for: {', '.join(missing)}")
        return problems

    def num(name):
        try:
            return float(b[name])
        except (TypeError, ValueError):
            problems.append(f"'{name}' must be a number.")
            return None

    for name in cfg.RAW_NUMERIC:
        v = num(name)
        if v is not None and v < 0:
            problems.append(f"'{name}' cannot be negative.")
    if not problems:
        if float(b["adults"]) + float(b["children"]) <= 0:
            problems.append("The booking needs at least one adult or child.")
        if float(b["stays_in_weekend_nights"]) + float(b["stays_in_week_nights"]) <= 0:
            problems.append("The stay needs at least one night.")
        if float(b["is_repeated_guest"]) not in (0.0, 1.0):
            problems.append("'is_repeated_guest' must be 0 or 1.")
    return problems


def build_input_frame(booking: dict) -> pd.DataFrame:
    """One-row DataFrame with the raw model columns in the training order."""
    return pd.DataFrame([{c: booking[c] for c in cfg.RAW_FEATURES}])


@dataclass
class Prediction:
    probability: float
    is_canceled: bool
    risk_level: str          # "Low", "Medium" or "High"
    threshold: float


def risk_level(probability: float, threshold: float) -> str:
    """Three risk bands defined relative to the decision threshold.

    High   : probability >= threshold  (the model predicts a cancellation)
    Medium : between 60 % of the threshold and the threshold (grey zone)
    Low    : below 60 % of the threshold
    """
    if probability >= threshold:
        return "High"
    if probability >= 0.6 * threshold:
        return "Medium"
    return "Low"


def predict_booking(model, booking: dict, threshold: float = DEFAULT_THRESHOLD) -> Prediction:
    """Validate, score and label a single booking."""
    problems = validate_booking(booking)
    if problems:
        raise ValueError(" ".join(problems))
    proba = float(model.predict_proba(build_input_frame(booking))[:, 1][0])
    return Prediction(
        probability=proba,
        is_canceled=proba >= threshold,
        risk_level=risk_level(proba, threshold),
        threshold=threshold,
    )


def recommendation(pred: Prediction, booking: dict) -> list[str]:
    """Practical, rule-based advice for hotel staff (not a model output)."""
    tips = []
    if pred.risk_level == "High":
        tips.append("Treat this booking as likely to cancel when planning inventory "
                    "(for example, include it in overbooking calculations).")
        if booking["deposit_type"] == "No Deposit":
            tips.append("Consider requesting a deposit or offering a small discount "
                        "for a non-refundable rate to secure the booking.")
        if booking["lead_time"] >= 180:
            tips.append("Long lead time: send a reminder or reconfirmation message "
                        "closer to arrival to confirm the guest's plans.")
        if booking["total_of_special_requests"] == 0:
            tips.append("The guest has made no special requests - a personalised "
                        "pre-arrival email can increase engagement.")
        if booking["market_segment"] in ("Online TA", "Groups", "Offline TA/TO"):
            tips.append("Check the cancellation terms of this sales channel and "
                        "consider a stricter policy for it.")
    elif pred.risk_level == "Medium":
        tips.append("Borderline risk: keep the booking, but monitor it and send a "
                    "confirmation reminder before arrival.")
        if booking["deposit_type"] == "No Deposit":
            tips.append("A partial deposit could reduce the cancellation risk.")
    else:
        tips.append("Low risk: no special action needed. Normal inventory planning "
                    "is appropriate.")
    return tips
