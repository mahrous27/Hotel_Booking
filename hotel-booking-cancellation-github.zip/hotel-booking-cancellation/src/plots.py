"""Matplotlib / Seaborn figures used by the training script and the notebook."""
from __future__ import annotations

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import roc_curve

sns.set_theme(style="whitegrid", context="notebook")
PALETTE = {"ok": "#2a9d8f", "bad": "#e76f51", "neutral": "#264653"}


def plot_model_comparison(cv_df: pd.DataFrame):
    """Bar chart of cross-validated ROC-AUC (with std) and F1 per model."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for ax, metric in zip(axes, ["roc_auc", "f1"]):
        d = cv_df.sort_values(f"cv_{metric}_mean")
        ax.barh(d["model"], d[f"cv_{metric}_mean"], xerr=d[f"cv_{metric}_std"],
                color=PALETTE["neutral"], alpha=.85)
        ax.set_title(f"Cross-validated {metric.upper().replace('_', '-')} (training data)")
        ax.set_xlabel(metric)
    fig.tight_layout()
    return fig


def plot_roc_curves(y_true, proba_by_model: dict):
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    for name, p in proba_by_model.items():
        fpr, tpr, _ = roc_curve(y_true, p)
        auc = np.trapezoid(tpr, fpr)
        ax.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random guess")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate (Recall)")
    ax.set_title("ROC curve - test set")
    ax.legend(loc="lower right")
    fig.tight_layout()
    return fig


def plot_confusion_matrices(cms: dict):
    """cms = {"title": 2x2 array}. Shows counts and row percentages."""
    fig, axes = plt.subplots(1, len(cms), figsize=(5.5 * len(cms), 4.5))
    axes = np.atleast_1d(axes)
    for ax, (title, cm) in zip(axes, cms.items()):
        cm = np.asarray(cm)
        pct = cm / cm.sum(axis=1, keepdims=True)
        labels = np.array([[f"{cm[i, j]:,}\n({pct[i, j]:.1%})" for j in range(2)] for i in range(2)])
        sns.heatmap(cm, annot=labels, fmt="", cmap="Blues", cbar=False, ax=ax,
                    xticklabels=["Not Canceled", "Canceled"],
                    yticklabels=["Not Canceled", "Canceled"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_threshold_analysis(table: pd.DataFrame, chosen: float):
    fig, ax = plt.subplots(figsize=(8, 4.8))
    for col, color in [("precision", "#e76f51"), ("recall", "#2a9d8f"), ("f1", "#264653")]:
        ax.plot(table["threshold"], table[col], lw=2, label=col.capitalize(), color=color)
    ax.axvline(chosen, color="gray", ls="--", label=f"Chosen threshold = {chosen:.2f}")
    ax.set_xlabel("Decision threshold on P(cancel)")
    ax.set_ylabel("Score")
    ax.set_title("Threshold analysis (out-of-fold predictions on training data)")
    ax.legend()
    fig.tight_layout()
    return fig


def plot_importance(df: pd.DataFrame, value_col: str, title: str, top: int = 15, err_col=None):
    d = df.head(top).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 0.38 * len(d) + 1.5))
    ax.barh(d["feature"], d[value_col], xerr=d[err_col] if err_col else None,
            color=PALETTE["neutral"], alpha=.9)
    ax.set_title(title)
    ax.set_xlabel(value_col.replace("_", " "))
    fig.tight_layout()
    return fig


def plot_cancel_rate(df: pd.DataFrame, col: str, title: str, rotate: int = 0):
    """Bar chart of cancellation rate per category with booking counts."""
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    sns.barplot(data=df, x=col, y="cancel_rate", color=PALETTE["neutral"], ax=ax)
    for i, (r, n) in enumerate(zip(df["cancel_rate"], df["bookings"])):
        ax.text(i, r + 0.01, f"{r:.0%}\n(n={n:,})", ha="center", va="bottom", fontsize=8)
    ax.set_ylim(0, min(1.05, df["cancel_rate"].max() + 0.18))
    ax.set_ylabel("Cancellation rate")
    ax.set_xlabel("")
    ax.set_title(title)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    plt.setp(ax.get_xticklabels(), rotation=rotate, ha="right" if rotate else "center")
    fig.tight_layout()
    return fig
