// Build docs/hotel_booking_cancellation.pptx from the REAL results in models/model_metadata.json
// Run from the project root:  node scripts/build_deck.js
const fs = require("fs");
const path = require("path");
const pptxgen = require("pptxgenjs");

const ROOT = path.resolve(__dirname, "..");
const meta = JSON.parse(fs.readFileSync(path.join(ROOT, "models/model_metadata.json"), "utf8"));
const FIG = (n) => path.join(ROOT, "reports/figures", n);
const tm = meta.test_metrics_final, t50 = meta.test_metrics_default_threshold;
const cmp = Object.fromEntries(meta.model_comparison.map((r) => [r.model, r]));
const perm = meta.permutation_importance;
const dash = meta.dashboard, clean = meta.cleaning_report;

const f3 = (x) => x.toFixed(3);
const pct = (x, d = 1) => (x * 100).toFixed(d) + "%";
const nf = (x) => x.toLocaleString("en-US");

// palette: deep teal dominant, cream surface, coral accent
const C = { dark: "0B3C49", teal: "2A9D8F", coral: "E76F51", cream: "F6F3EC", ink: "1F2A30", mute: "5B6B73", white: "FFFFFF", line: "D9D4C7" };
const HEAD = "Georgia", BODY = "Calibri";

function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}
function fit(file, x, y, w, h) {
  const s = pngSize(file), r = s.w / s.h;
  let iw = w, ih = w / r;
  if (ih > h) { ih = h; iw = h * r; }
  return { path: file, x: x + (w - iw) / 2, y: y + (h - ih) / 2, w: iw, h: ih };
}

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10 x 5.625 in
pres.title = "Hotel Booking Cancellation Prediction";
pres.author = "ML Final Project";

let n = 0;
function content(title, notes) {
  const s = pres.addSlide();
  n += 1;
  s.background = { color: C.cream };
  s.addText(title, { x: 0.5, y: 0.3, w: 9, h: 0.7, fontFace: HEAD, fontSize: 26, bold: true, color: C.dark, margin: 0, isTextBox: true, valign: "middle" });
  s.addText(String(n), { x: 9.1, y: 5.2, w: 0.5, h: 0.25, fontFace: BODY, fontSize: 10, color: C.mute, align: "right", margin: 0, isTextBox: true });
  if (notes) s.addNotes(notes);
  return s;
}
function card(s, x, y, w, h, fill = C.white) {
  s.addShape(pres.ShapeType.roundRect, { x, y, w, h, fill: { color: fill }, line: { color: C.line, width: 0.75 }, rectRadius: 0.08 });
}
function stat(s, x, y, w, big, small, color = C.teal) {
  card(s, x, y, w, 1.25);
  s.addText(big, { x: x + 0.15, y: y + 0.12, w: w - 0.3, h: 0.6, fontFace: HEAD, fontSize: 28, bold: true, color, margin: 0, isTextBox: true, valign: "middle" });
  s.addText(small, { x: x + 0.15, y: y + 0.74, w: w - 0.3, h: 0.45, fontFace: BODY, fontSize: 12, color: C.mute, margin: 0, isTextBox: true, valign: "top" });
}

// 1 ── Title
{
  const s = pres.addSlide(); n += 1;
  s.background = { color: C.dark };
  s.addText("Hotel Booking\nCancellation Prediction", { x: 0.6, y: 0.9, w: 6.1, h: 1.9, fontFace: HEAD, fontSize: 34, bold: true, color: C.white, margin: 0, isTextBox: true, valign: "top" });
  s.addText("Machine Learning Final Project", { x: 0.6, y: 3.0, w: 6, h: 0.4, fontFace: BODY, fontSize: 18, color: "9ED8CF", margin: 0, isTextBox: true });
  s.addText("Predicting which bookings will be canceled, and what a hotel can do about it", { x: 0.6, y: 3.5, w: 5.6, h: 0.7, fontFace: BODY, fontSize: 14, color: C.white, margin: 0, isTextBox: true, valign: "top" });
  s.addShape(pres.ShapeType.roundRect, { x: 6.9, y: 1.4, w: 2.6, h: 2.6, fill: { color: C.teal }, line: { color: C.teal }, rectRadius: 0.15 });
  s.addText(f3(tm.roc_auc), { x: 6.9, y: 1.65, w: 2.6, h: 1.0, fontFace: HEAD, fontSize: 44, bold: true, color: C.white, align: "center", margin: 0, isTextBox: true, valign: "middle" });
  s.addText("test ROC-AUC\n(untouched test set)", { x: 6.9, y: 2.7, w: 2.6, h: 0.8, fontFace: BODY, fontSize: 13, color: C.white, align: "center", margin: 0, isTextBox: true, valign: "top" });
  s.addNotes("Introduce the project: predict whether a hotel booking will be canceled using the Kaggle Hotel Booking Demand data.");
}

// 2 ── Problem statement
{
  const s = content("Problem: cancellations leave rooms empty",
    "Raw data has many duplicate rows, so the raw cancellation rate (37.0%) is higher than the cleaned rate (27.7%).");
  stat(s, 0.5, 1.2, 2.9, nf(dash.total_bookings_raw), "historical bookings (raw file, 32 columns)");
  stat(s, 3.55, 1.2, 2.9, pct(dash.cancel_rate_raw), "of raw bookings were canceled", C.coral);
  stat(s, 6.6, 1.2, 2.9, pct(dash.cancel_rate_clean), `canceled after cleaning (${nf(dash.total_bookings_clean)} bookings)`, C.coral);
  card(s, 0.5, 2.75, 9.0, 2.2);
  s.addText([
    { text: "The question", options: { bold: true, color: C.dark, breakLine: true } },
    { text: "Given what is known when a booking is made, will it be canceled (is_canceled = 1) or not (0)?", options: { breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Why it matters", options: { bold: true, color: C.dark, breakLine: true } },
    { text: "A canceled booking that nobody saw coming is an empty room and lost revenue. Overbooking blindly has a cost too: relocating a guest who does show up.", options: {} },
  ], { x: 0.75, y: 2.9, w: 8.5, h: 1.9, fontFace: BODY, fontSize: 15, color: C.ink, margin: 0, isTextBox: true, valign: "top" });
}

// 3 ── Business objectives
{
  const s = content("Business objectives", "Four objectives of the project, from understanding to action.");
  const items = [
    ["1", "Understand", "Analyse historical bookings and find the factors behind cancellations."],
    ["2", "Predict", "Say whether a new booking will be canceled."],
    ["3", "Quantify", "Estimate the cancellation probability, not just a yes/no."],
    ["4", "Act", "Support reminders, deposit policy and overbooking decisions to cut losses."],
  ];
  items.forEach((it, i) => {
    const x = 0.5 + (i % 2) * 4.6, y = 1.2 + Math.floor(i / 2) * 1.95;
    card(s, x, y, 4.4, 1.75);
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.2, y: y + 0.25, w: 0.55, h: 0.55, fill: { color: C.teal }, line: { color: C.teal } });
    s.addText(it[0], { x: x + 0.2, y: y + 0.25, w: 0.55, h: 0.55, fontFace: HEAD, fontSize: 18, bold: true, color: C.white, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(it[1], { x: x + 0.95, y: y + 0.25, w: 3.3, h: 0.55, fontFace: HEAD, fontSize: 20, bold: true, color: C.dark, valign: "middle", margin: 0, isTextBox: true });
    s.addText(it[2], { x: x + 0.25, y: y + 0.95, w: 3.95, h: 0.7, fontFace: BODY, fontSize: 14, color: C.ink, valign: "top", margin: 0, isTextBox: true });
  });
}

// 4 ── Dataset
{
  const s = content("Dataset: Hotel Booking Demand (Kaggle)", "Cleaning rules are row-level and rule-based, so doing them before the split does not leak information.");
  s.addText([
    { text: "City hotel and resort hotel in Portugal", options: { bullet: true, breakLine: true } },
    { text: "119,390 rows × 32 columns; target is_canceled", options: { bullet: true, breakLine: true } },
    { text: `Model uses ${meta.features_used.raw.length} booking-form fields plus ${meta.features_used.engineered.length} engineered features`, options: { bullet: true, breakLine: true } },
    { text: "Leakage columns removed: reservation_status, reservation_status_date", options: { bullet: true, breakLine: true } },
    { text: "Moderate class imbalance, so accuracy alone is not enough", options: { bullet: true } },
  ], { x: 0.5, y: 1.2, w: 4.6, h: 3.4, fontFace: BODY, fontSize: 15, color: C.ink, paraSpaceAfter: 8, valign: "top", margin: 0, isTextBox: true });
  const steps = [
    [nf(clean.rows_raw), "raw bookings", C.dark],
    ["−" + nf(clean.duplicates_removed), "exact duplicates", C.coral],
    ["−" + nf(clean.zero_guest_removed + clean.zero_night_removed + clean.invalid_adr_removed + clean.extreme_party_removed), "invalid rows (no guests, 0 nights, bad price, huge party)", C.coral],
    [nf(clean.rows_clean), "clean bookings used", C.teal],
  ];
  steps.forEach((st, i) => {
    const y = 1.2 + i * 0.95;
    card(s, 5.5, y, 4.0, 0.82);
    s.addText(st[0], { x: 5.65, y: y + 0.05, w: 1.5, h: 0.72, fontFace: HEAD, fontSize: 20, bold: true, color: st[2], valign: "middle", margin: 0, isTextBox: true });
    s.addText(st[1], { x: 7.2, y: y + 0.05, w: 2.2, h: 0.72, fontFace: BODY, fontSize: 12, color: C.ink, valign: "middle", margin: 0, isTextBox: true });
  });
}

// 5 ── EDA
{
  const s = content("EDA: when, how and who books matters", "Lead time and sales channel are the clearest drivers. Rates computed on the cleaned data.");
  const a = fit(FIG("eda_lead_time.png"), 0.5, 1.1, 4.4, 2.9);
  const b = fit(FIG("eda_market_segment.png"), 5.1, 1.1, 4.4, 2.9);
  s.addImage(a); s.addImage(b);
  const by = Object.fromEntries(dash.by_lead_time.map((r) => [r.lead_time_group, r.cancel_rate]));
  const seg = Object.fromEntries(dash.by_market_segment.map((r) => [r.market_segment, r.cancel_rate]));
  const prev = Object.fromEntries(dash.by_previous_cancellation.map((r) => [r.prev_cancel_group, r.cancel_rate]));
  const facts = [
    [`${pct(by["0-7 d"])} → ${pct(by["181-365 d"])}`, "cancellation rate, 0-7 days vs 181-365 days of lead time"],
    [`${pct(seg["Online TA"])} vs ${pct(seg["Direct"])}`, "online travel agency vs direct bookings"],
    [pct(prev["Has previous cancellation"], 0), `cancel again after a previous cancellation (vs ${pct(prev["No previous cancellation"], 0)})`],
  ];
  facts.forEach((f, i) => {
    const x = 0.5 + i * 3.05;
    card(s, x, 4.1, 2.9, 1.0);
    s.addText(f[0], { x: x + 0.12, y: 4.15, w: 2.66, h: 0.45, fontFace: HEAD, fontSize: 16, bold: true, color: C.coral, margin: 0, isTextBox: true, valign: "middle" });
    s.addText(f[1], { x: x + 0.12, y: 4.6, w: 2.66, h: 0.45, fontFace: BODY, fontSize: 10.5, color: C.mute, margin: 0, isTextBox: true, valign: "top" });
  });
}

// 6 ── Preprocessing
{
  const s = content("Preprocessing: split first, then fit", "Everything that learns from data (imputer, scaler, encoder, model, tuning, threshold) only sees the training set.");
  const flow = ["Clean\nrows", "Split 80/20\n(stratified)", "Feature\nengineering", "Impute · scale ·\none-hot encode", "Model"];
  flow.forEach((t, i) => {
    const x = 0.5 + i * 1.85;
    s.addShape(pres.ShapeType.roundRect, { x, y: 1.25, w: 1.6, h: 1.0, fill: { color: i === 1 ? C.coral : C.teal }, line: { color: C.white, width: 0 }, rectRadius: 0.08 });
    s.addText(t, { x, y: 1.25, w: 1.6, h: 1.0, fontFace: BODY, fontSize: 13, bold: true, color: C.white, align: "center", valign: "middle", margin: 4, isTextBox: true });
    if (i < flow.length - 1) s.addText("›", { x: x + 1.6, y: 1.25, w: 0.25, h: 1.0, fontFace: HEAD, fontSize: 24, bold: true, color: C.mute, align: "center", valign: "middle", margin: 0, isTextBox: true });
  });
  card(s, 0.5, 2.55, 4.4, 2.45);
  s.addText([
    { text: "Engineered features", options: { bold: true, color: C.dark, breakLine: true } },
    { text: "total nights and guests", options: { bullet: true, breakLine: true } },
    { text: "ADR per person", options: { bullet: true, breakLine: true } },
    { text: "weekend share of nights", options: { bullet: true, breakLine: true } },
    { text: "flags: children, special requests, previous cancellation", options: { bullet: true, breakLine: true } },
    { text: "Fixed outlier caps (e.g. ADR ≤ 500); rare countries grouped", options: { bullet: true } },
  ], { x: 0.7, y: 2.65, w: 4.0, h: 2.25, fontFace: BODY, fontSize: 13, color: C.ink, paraSpaceAfter: 4, valign: "top", margin: 0, isTextBox: true });
  card(s, 5.1, 2.55, 4.4, 2.45, "FDEEE9");
  const lk = meta.parking_leakage_check;
  s.addText([
    { text: "Leakage found and removed", options: { bold: true, color: C.coral, breakLine: true } },
    { text: "reservation_status (+ date) restate the outcome", options: { bullet: true, breakLine: true } },
    { text: `Parking: ${lk.cancellations_among_them} of ${nf(lk.bookings_with_parking)} bookings with a parking space were canceled, so the field is recorded after the stay`, options: { bullet: true, breakLine: true } },
    { text: `Keeping it inflated test ROC-AUC from ${f3(lk.test_roc_auc_without_parking)} to ${f3(lk.test_roc_auc_with_parking)}`, options: { bullet: true } },
  ], { x: 5.3, y: 2.65, w: 4.0, h: 2.25, fontFace: BODY, fontSize: 13, color: C.ink, paraSpaceAfter: 4, valign: "top", margin: 0, isTextBox: true });
}

// 7 ── Algorithms
{
  const s = content("Four algorithms, one fair pipeline", "Each model sits in the same pipeline; only Logistic Regression gets scaled numeric inputs.");
  const algos = [
    ["Logistic Regression", "Weighs each feature and turns the sum into a probability.", "Fast, interpretable", "Only straight-line boundaries"],
    ["Decision Tree", "Asks a chain of yes/no questions that split bookings into purer groups.", "Easy to explain", "Over-fits, unstable"],
    ["Random Forest", "Averages many trees trained on random samples of rows and features.", "Accurate, robust", "Bigger, less transparent"],
    ["Gradient Boosting", "Builds trees one by one, each fixing the previous errors.", "Strong on tabular data", "Slower, sensitive to tuning"],
  ];
  algos.forEach((a, i) => {
    const x = 0.5 + i * 2.28;
    card(s, x, 1.2, 2.15, 3.3);
    s.addText(a[0], { x: x + 0.12, y: 1.3, w: 1.91, h: 0.6, fontFace: HEAD, fontSize: 15, bold: true, color: C.dark, margin: 0, isTextBox: true, valign: "middle" });
    s.addText(a[1], { x: x + 0.12, y: 1.95, w: 1.91, h: 1.4, fontFace: BODY, fontSize: 12, color: C.ink, margin: 0, isTextBox: true, valign: "top" });
    s.addText([{ text: "+ " + a[2], options: { color: C.teal, bold: true, breakLine: true } }, { text: "− " + a[3], options: { color: C.coral, bold: true } }],
      { x: x + 0.12, y: 3.3, w: 1.91, h: 1.1, fontFace: BODY, fontSize: 12, paraSpaceAfter: 6, margin: 0, isTextBox: true, valign: "top" });
  });
}

// 8 ── Model comparison
{
  const s = content("Model comparison: Random Forest wins", "Cross-validation on the training set only. Selection by ROC-AUC, not accuracy. Tuning improved 3-fold CV ROC-AUC from " + f3(meta.untuned_cv_roc_auc) + " to " + f3(meta.tuning_cv_roc_auc) + ", which is within noise.");
  const names = ["Logistic Regression", "Decision Tree", "Random Forest", "Gradient Boosting"];
  s.addChart(pres.charts.BAR, [{ name: "CV ROC-AUC", labels: names, values: names.map((m) => +cmp[m].cv_roc_auc_mean.toFixed(4)) }], {
    x: 0.4, y: 1.1, w: 5.0, h: 3.9, barDir: "bar", chartColors: [C.teal],
    showTitle: true, title: "5-fold CV ROC-AUC (training data)", titleFontSize: 13, titleColor: C.dark, titleFontFace: "+mn-lt",
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 11, dataLabelFormatCode: "0.000", dataLabelFontFace: "+mn-lt",
    valAxisMinVal: 0.7, valAxisMaxVal: 0.9, valAxisLabelFontSize: 10, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt",
    valGridLine: { color: "E3DED2", size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, catAxisOrientation: "maxMin",
  });
  const hdr = (t) => ({ text: t, options: { bold: true, color: C.white, fill: { color: C.dark }, align: "center", fontSize: 11 } });
  const rows = [[hdr("Model"), hdr("F1"), hdr("Prec."), hdr("Recall")]];
  names.forEach((m) => {
    const bold = m === "Random Forest";
    const c = (t, al = "center") => ({ text: t, options: { bold, align: al, fontSize: 11, color: C.ink } });
    rows.push([c(m, "left"), c(f3(cmp[m].cv_f1_mean)), c(f3(cmp[m].cv_precision_mean)), c(f3(cmp[m].cv_recall_mean))]);
  });
  s.addTable(rows, { x: 5.6, y: 1.25, w: 3.9, colW: [1.5, 0.8, 0.8, 0.8], rowH: 0.36, fontFace: BODY, border: { type: "solid", color: C.line, pt: 0.5 }, fill: { color: C.white } });
  s.addText([
    { text: "Cancellation depends on combinations (channel × lead time × country × requests): trees capture these, a linear model cannot.", options: { breakLine: true } },
    { text: `Tuning (RandomizedSearchCV) moved CV ROC-AUC only ${meta.untuned_cv_roc_auc.toFixed(4)} → ${meta.tuning_cv_roc_auc.toFixed(4)}: no meaningful gain.`, options: {} },
  ], { x: 5.6, y: 3.2, w: 3.9, h: 1.8, fontFace: BODY, fontSize: 12.5, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true, valign: "top" });
}

// 9 ── Evaluation
{
  const s = content(`Test-set evaluation (threshold ${meta.threshold.toFixed(2)})`, "Threshold chosen on out-of-fold training predictions (best F1). Lowering it from 0.50 raises recall at the cost of precision.");
  const m = [["Recall", tm.recall, C.teal], ["Precision", tm.precision, C.coral], ["F1-score", tm.f1, C.dark], ["ROC-AUC", tm.roc_auc, C.dark]];
  m.forEach((it, i) => {
    const x = 0.5 + i * 2.28;
    card(s, x, 1.1, 2.15, 1.0);
    s.addText(f3(it[1]), { x: x + 0.1, y: 1.15, w: 1.95, h: 0.55, fontFace: HEAD, fontSize: 24, bold: true, color: it[2], align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(it[0], { x: x + 0.1, y: 1.7, w: 1.95, h: 0.3, fontFace: BODY, fontSize: 12, color: C.mute, align: "center", margin: 0, isTextBox: true });
  });
  s.addImage(fit(FIG("confusion_matrices.png"), 0.4, 2.25, 5.9, 2.85));
  s.addText([
    { text: `Catches ${pct(tm.recall, 0)} of real cancellations (${nf(tm.tp)} of ${nf(tm.tp + tm.fn)})`, options: { bullet: true, breakLine: true } },
    { text: `${pct(tm.precision, 0)} of warnings are right; ${nf(tm.fp)} false alarms`, options: { bullet: true, breakLine: true } },
    { text: `At 0.50: recall ${pct(t50.recall, 0)}, precision ${pct(t50.precision, 0)}`, options: { bullet: true, breakLine: true } },
    { text: "Weak spot: last-minute bookings (rare cancellations) and online-agency bookings", options: { bullet: true } },
  ], { x: 6.5, y: 2.3, w: 3.0, h: 2.8, fontFace: BODY, fontSize: 12.5, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true, valign: "top" });
}

// 10 ── Feature importance
{
  const s = content("What drives the predictions", "Permutation importance on the test set: drop in ROC-AUC when a column is shuffled. Importance is not causation.");
  s.addImage(fit(FIG("permutation_importance.png"), 0.4, 1.1, 5.3, 3.95));
  const top = perm.slice(0, 3).map((r) => r.feature);
  const nice = { market_segment: "market segment", country: "country", lead_time: "lead time" };
  s.addText([
    { text: "Top 3: " + top.map((t) => nice[t] || t).join(", "), options: { bold: true, color: C.dark, breakLine: true } },
    { text: "Who books, through which channel and how far ahead describes most of the risk", options: { bullet: true, breakLine: true } },
    { text: "Special requests: engaged guests cancel less", options: { bullet: true, breakLine: true } },
    { text: "Price and customer type come next; previous cancellations matter when present", options: { bullet: true, breakLine: true } },
    { text: "Deposit type ranks lower than expected: its few 'Non Refund' bookings are also identified by other columns", options: { bullet: true } },
  ], { x: 5.9, y: 1.2, w: 3.6, h: 3.8, fontFace: BODY, fontSize: 12.5, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true, valign: "top" });
}

// 11 ── App demo
{
  const s = content("Streamlit web app", "Run with: streamlit run app.py. Replace the placeholder with a screenshot of the Prediction page.");
  const pages = [["Home", "Project description, objectives, dataset information"], ["Prediction", "Booking form → prediction, probability, risk bar and advice"], ["Analytics Dashboard", "Statistics, cancellation factors, model metrics, interactive charts"]];
  pages.forEach((p, i) => {
    const y = 1.2 + i * 1.1;
    card(s, 0.5, y, 3.6, 0.95);
    s.addText(p[0], { x: 0.65, y: y + 0.05, w: 3.3, h: 0.35, fontFace: HEAD, fontSize: 14, bold: true, color: C.dark, margin: 0, isTextBox: true, valign: "middle" });
    s.addText(p[1], { x: 0.65, y: y + 0.42, w: 3.3, h: 0.5, fontFace: BODY, fontSize: 11, color: C.mute, margin: 0, isTextBox: true, valign: "top" });
  });
  s.addText("streamlit run app.py", { x: 0.5, y: 4.55, w: 3.6, h: 0.4, fontFace: "Consolas", fontSize: 12, color: C.white, fill: { color: C.dark }, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addShape(pres.ShapeType.roundRect, { x: 4.4, y: 1.2, w: 5.1, h: 3.75, fill: { color: C.white }, line: { color: C.mute, width: 1.25, dashType: "dash" }, rectRadius: 0.08 });
  s.addText("Screenshot placeholder\nInsert a screenshot of the Prediction page here", { x: 4.4, y: 1.2, w: 5.1, h: 3.75, fontFace: BODY, fontSize: 14, color: C.mute, align: "center", valign: "middle", margin: 0, isTextBox: true });
}

// 12 ── Conclusion
{
  const s = pres.addSlide(); n += 1;
  s.background = { color: C.dark };
  s.addText("Conclusion and future improvements", { x: 0.5, y: 0.3, w: 9, h: 0.7, fontFace: HEAD, fontSize: 26, bold: true, color: C.white, margin: 0, isTextBox: true, valign: "middle" });
  s.addText([
    { text: "What we achieved", options: { bold: true, color: "9ED8CF", fontSize: 16, breakLine: true } },
    { text: `Leakage-free pipeline; tuned Random Forest, test ROC-AUC ${f3(tm.roc_auc)}`, options: { bullet: true, breakLine: true } },
    { text: `Recall ${pct(tm.recall, 0)} at precision ${pct(tm.precision, 0)} (threshold ${meta.threshold.toFixed(2)})`, options: { bullet: true, breakLine: true } },
    { text: "Same code in notebook, training script and app", options: { bullet: true, breakLine: true } },
    { text: "Actions: flag high-risk bookings, reconfirm early, test deposit rules, overbook with probabilities", options: { bullet: true } },
  ], { x: 0.5, y: 1.2, w: 4.4, h: 3.6, fontFace: BODY, fontSize: 13.5, color: C.white, paraSpaceAfter: 7, margin: 0, isTextBox: true, valign: "top" });
  s.addText([
    { text: "Limits and next steps", options: { bold: true, color: "F4A58F", fontSize: 16, breakLine: true } },
    { text: "Two Portuguese hotels, 2015-2017", options: { bullet: true, breakLine: true } },
    { text: "Tuning added almost nothing: add features (arrival season, room type, payment)", options: { bullet: true, breakLine: true } },
    { text: "Try time-based split, calibration, XGBoost/LightGBM, SHAP in the app", options: { bullet: true, breakLine: true } },
    { text: "Use real revenue and relocation costs to set the threshold", options: { bullet: true } },
  ], { x: 5.2, y: 1.2, w: 4.3, h: 3.6, fontFace: BODY, fontSize: 13.5, color: C.white, paraSpaceAfter: 7, margin: 0, isTextBox: true, valign: "top" });
  s.addNotes("Close with the honest results and the plan: better features matter more than more tuning.");
}

pres.writeFile({ fileName: path.join(ROOT, "docs/hotel_booking_cancellation.pptx") }).then((f) => console.log("written", f));
