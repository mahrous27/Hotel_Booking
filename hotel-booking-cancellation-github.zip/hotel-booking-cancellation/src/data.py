"""Loading, cleaning and splitting the Hotel Booking Demand data."""
from __future__ import annotations

import pandas as pd
from sklearn.model_selection import train_test_split

from . import config as cfg


def load_raw_data(path=cfg.DATA_PATH) -> pd.DataFrame:
    """Read the raw CSV. Raises a helpful error if the file is missing."""
    if not path.exists():
        raise FileNotFoundError(cfg.DOWNLOAD_HELP.format(path=path))
    return pd.read_csv(path)


def clean_data(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Remove duplicated and clearly invalid booking records.

    These are *row-level, rule-based* removals. They do not compute any
    statistic from the data, so doing them before the train/test split does
    not leak information. Removing exact duplicates BEFORE splitting is
    actually important: otherwise the same booking could land in both the
    training and the test set and inflate the test score.

    Returns the cleaned frame and a small report (rows removed per rule).
    """
    report = {"rows_raw": int(len(df))}
    out = df.copy()

    # 1. exact duplicate rows
    before = len(out)
    out = out.drop_duplicates()
    report["duplicates_removed"] = int(before - len(out))

    # 2. bookings with no adult/child guest (babies alone cannot book)
    before = len(out)
    guests = out["adults"] + out["children"].fillna(0)
    out = out[guests > 0]
    report["zero_guest_removed"] = int(before - len(out))

    # 3. bookings with zero nights
    before = len(out)
    nights = out["stays_in_weekend_nights"] + out["stays_in_week_nights"]
    out = out[nights > 0]
    report["zero_night_removed"] = int(before - len(out))

    # 4. impossible / extreme prices (negative ADR, or ADR > 1000 which is a
    #    single obvious data-entry error of 5400 in this dataset)
    before = len(out)
    out = out[(out["adr"] >= 0) & (out["adr"] <= 1000)]
    report["invalid_adr_removed"] = int(before - len(out))

    # 5. absurd party sizes (adults > 10)
    before = len(out)
    out = out[out["adults"] <= 10]
    report["extreme_party_removed"] = int(before - len(out))

    out = out.reset_index(drop=True)
    report["rows_clean"] = int(len(out))
    report["cancel_rate_clean"] = float(out[cfg.TARGET].mean())
    return out, report


def split_data(df_clean: pd.DataFrame):
    """Stratified train/test split of the cleaned data.

    Only the model input columns (`cfg.RAW_FEATURES`) are returned, so the
    leakage columns (reservation_status, ...) can never reach the model.
    The split happens BEFORE any transformer is fitted.
    """
    X = df_clean[cfg.RAW_FEATURES].copy()
    y = df_clean[cfg.TARGET].copy()
    return train_test_split(
        X, y, test_size=cfg.TEST_SIZE, stratify=y, random_state=cfg.RANDOM_STATE
    )


def load_and_split():
    """Convenience helper: raw CSV -> cleaned data -> train/test split."""
    raw = load_raw_data()
    clean, report = clean_data(raw)
    X_train, X_test, y_train, y_test = split_data(clean)
    return raw, clean, report, X_train, X_test, y_train, y_test
