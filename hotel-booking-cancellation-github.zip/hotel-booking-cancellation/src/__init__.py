"""Hotel Booking Cancellation Prediction - shared project code.

The training script, the Streamlit app and the notebook all import from this
package so that every part of the project uses *exactly* the same data
cleaning, feature engineering and preprocessing logic.
"""
