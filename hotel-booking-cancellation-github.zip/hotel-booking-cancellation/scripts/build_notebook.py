"""Build and execute notebooks/hotel_booking_analysis.ipynb.

This helper writes the notebook, runs every code cell in order and stores the
real outputs (text, tables and charts) inside the .ipynb file, so the notebook
opens with results already visible. You can also simply open the notebook in
Jupyter / VS Code and use "Run All" - the cells are ordinary Python.

    python scripts/build_notebook.py
"""
from __future__ import annotations

import ast
import base64
import contextlib
import io
import json
import sys
import time
import traceback
import uuid
import warnings
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NB_DIR = ROOT / "notebooks"
NB_PATH = NB_DIR / "hotel_booking_analysis.ipynb"

CELLS: list[tuple[str, str]] = []


def md(text: str) -> None:
    CELLS.append(("markdown", text.strip("\n")))


def code(text: str) -> None:
    CELLS.append(("code", text.strip("\n")))


# =============================================================================
# 0. Title
# =============================================================================
md(r'''
# 🏨 Hotel Booking Cancellation Prediction
**Machine Learning Final Project**

**Goal:** predict whether a hotel booking will be **canceled** (`is_canceled = 1`) or **not canceled** (`0`), estimate the cancellation probability, and turn the findings into practical advice for hotel managers.

**Dataset:** *Hotel Booking Demand* (Kaggle, `jessemostipak/hotel-booking-demand`) - bookings for a city hotel and a resort hotel in Portugal.

### Notebook roadmap
1. Setup and data understanding
2. Exploratory Data Analysis (univariate, bivariate, multivariate) and business insights
3. Data preprocessing (cleaning, leakage, split, pipeline)
4. Machine-learning models and comparison
5. Model optimisation (cross-validation, hyper-parameter tuning)
6. Threshold analysis
7. Final evaluation on the untouched test set and error analysis
8. Feature importance and business recommendations
9. Saving the model and conclusion

> **How the project fits together:** all cleaning, feature engineering and preprocessing code lives in the `src/` package. This notebook, the training script (`python -m src.train`) and the Streamlit app (`app.py`) all import the *same* code, so they can never disagree.
''')

# =============================================================================
# 1. Setup
# =============================================================================
md(r'''
## 1. Setup
We import the libraries and the shared project code. The first lines make sure Python can find the `src/` folder whether the notebook is started from the project root or from the `notebooks/` folder.
''')
code(r'''
import sys, json, warnings
from pathlib import Path

ROOT = Path.cwd() if (Path.cwd() / "src").exists() else Path.cwd().parent
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold, cross_validate, RandomizedSearchCV
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, classification_report, roc_curve)

from src import config as cfg
from src import plots
from src.data import load_raw_data, clean_data, split_data
from src.features import add_features, make_pipeline
from src.modeling import (get_models, get_param_distributions, metrics_at_threshold,
                          threshold_table, best_f1_threshold)
from src.analysis import (cancel_rate_by, lead_time_bin, adr_bin, LEAD_LABELS, ADR_LABELS,
                          error_analysis, aggregate_native_importance, permutation_importance_raw)

warnings.filterwarnings("ignore")
pd.set_option("display.max_columns", 50)
pd.set_option("display.width", 200)
sns.set_theme(style="whitegrid")
cfg.FIGURES_DIR.mkdir(parents=True, exist_ok=True)

def savefig(name):
    """Save the current figure to reports/figures (used by the README)."""
    plt.savefig(cfg.FIGURES_DIR / name, dpi=150, bbox_inches="tight")

print("Project root:", ROOT)
print("Random seed :", cfg.RANDOM_STATE)
''')

# =============================================================================
# 2. Data understanding
# =============================================================================
md(r'''
## 2. Data Understanding
### 2.1 Load the data
If the file is missing, `load_raw_data()` raises an error explaining how to download it from Kaggle and where to put it (`data/hotel_bookings.csv`).
''')
code(r'''
raw = load_raw_data()
print("Dataset dimensions:", raw.shape, "-> rows, columns")
raw.head()
''')
md(r'''
### 2.2 Data types and column descriptions
''')
code(r'''
descriptions = {
    "hotel": "Hotel type: City Hotel or Resort Hotel",
    "is_canceled": "TARGET - 1 if the booking was canceled, 0 otherwise",
    "lead_time": "Days between booking date and arrival date",
    "arrival_date_year": "Year of arrival",
    "arrival_date_month": "Month of arrival",
    "arrival_date_week_number": "Week number of arrival",
    "arrival_date_day_of_month": "Day of month of arrival",
    "stays_in_weekend_nights": "Weekend nights (Sat/Sun) booked",
    "stays_in_week_nights": "Week nights (Mon-Fri) booked",
    "adults": "Number of adults",
    "children": "Number of children",
    "babies": "Number of babies",
    "meal": "Meal package: BB, HB, FB, SC (self catering) or Undefined",
    "country": "Country of origin (ISO 3-letter code)",
    "market_segment": "Market segment (Online TA, Offline TA/TO, Direct, Corporate, Groups, ...)",
    "distribution_channel": "Booking distribution channel (TA/TO, Direct, Corporate, GDS)",
    "is_repeated_guest": "1 if the guest has stayed before",
    "previous_cancellations": "Number of earlier bookings this customer canceled",
    "previous_bookings_not_canceled": "Number of earlier bookings this customer did NOT cancel",
    "reserved_room_type": "Room type reserved (coded)",
    "assigned_room_type": "Room type finally assigned (coded) - known late",
    "booking_changes": "Number of changes made to the booking - known late",
    "deposit_type": "No Deposit, Non Refund or Refundable",
    "agent": "ID of the travel agency (anonymised)",
    "company": "ID of the company that paid (anonymised, ~94 % missing)",
    "days_in_waiting_list": "Days the booking was on the waiting list",
    "customer_type": "Contract, Group, Transient or Transient-Party",
    "adr": "Average Daily Rate = revenue per room per night",
    "required_car_parking_spaces": "Car parking spaces requested",
    "total_of_special_requests": "Number of special requests (e.g. twin bed, high floor)",
    "reservation_status": "LEAKAGE - final status: Canceled, Check-Out or No-Show",
    "reservation_status_date": "LEAKAGE - date the final status was set",
}
info = pd.DataFrame({
    "dtype": raw.dtypes.astype(str),
    "non_null": raw.notna().sum(),
    "unique_values": raw.nunique(),
    "description": pd.Series(descriptions),
})
info
''')
md(r'''
### 2.3 Missing values and duplicate records
''')
code(r'''
missing = pd.DataFrame({"missing": raw.isna().sum(), "percent": (raw.isna().mean() * 100).round(2)})
print("Columns with missing values:")
display(missing[missing["missing"] > 0])

n_dup = raw.duplicated().sum()
print(f"\nExact duplicate rows: {n_dup:,} ({n_dup / len(raw):.1%} of the data)")
''')
md(r'''
**What this means**
* `children` (4 missing) and `country` (488 missing) have very few gaps - we fill them with `0` and `"Unknown"`.
* `agent` and `company` are ID codes with many gaps (`company` is ~94 % empty); we do not use them.
* About **27 % of the rows are exact duplicates**. A duplicate is the same booking counted more than once. If one copy lands in the training set and its twin in the test set, the model is "tested" on something it has already seen, so we remove duplicates *before* splitting.
''')
md(r'''
### 2.4 Target variable distribution
''')
code(r'''
counts = raw["is_canceled"].value_counts().sort_index()
pct = raw["is_canceled"].value_counts(normalize=True).sort_index() * 100
print(pd.DataFrame({"bookings": counts, "percent": pct.round(2)}).rename(index={0: "Not canceled (0)", 1: "Canceled (1)"}))

fig, ax = plt.subplots(figsize=(5, 4))
sns.countplot(data=raw, x="is_canceled", palette=["#2a9d8f", "#e76f51"], ax=ax)
ax.set_xticklabels(["Not canceled", "Canceled"]); ax.set_xlabel(""); ax.set_title("Target distribution (raw data)")
for p in ax.patches:
    ax.annotate(f"{int(p.get_height()):,}", (p.get_x() + p.get_width() / 2, p.get_height()), ha="center", va="bottom")
savefig("eda_target_distribution.png")
''')
md(r'''
The classes are moderately imbalanced (more non-canceled bookings than canceled ones), which is why **accuracy alone is not enough**: a model that always says "not canceled" would already be right most of the time but would never find a single cancellation.

### 2.5 Statistical summaries
''')
code(r'''
display(raw.describe().T.round(2))
print("Categorical columns:")
raw.describe(include="object").T
''')
md(r'''
Things worth noticing: `adr` has a minimum below 0 and a maximum of 5400; `adults` reaches 55; `lead_time` reaches 737 days; some rows have 0 guests or 0 nights. These are either outliers or invalid records and are handled in the cleaning step.
''')

# =============================================================================
# 3. EDA
# =============================================================================
md(r'''
## 3. Exploratory Data Analysis (EDA)
For the relationship plots we use the **cleaned** data (exact duplicates and clearly invalid rows removed with `clean_data`, explained in Section 4), because duplicates would count the same booking several times.
''')
code(r'''
clean, clean_report = clean_data(raw)
print(json.dumps(clean_report, indent=2))
eda = clean.copy()
eda["lead_time_group"] = lead_time_bin(eda["lead_time"])
eda["adr_group"] = adr_bin(eda["adr"])
print("\nOverall cancellation rate (cleaned data): {:.1%}".format(eda["is_canceled"].mean()))
''')
md(r'''
### 3.1 Univariate analysis - one variable at a time
''')
code(r'''
fig, axes = plt.subplots(2, 3, figsize=(16, 8))
sns.histplot(eda["lead_time"], bins=50, ax=axes[0, 0], color="#264653"); axes[0, 0].set_title("Lead time (days)")
sns.histplot(eda["adr"].clip(upper=400), bins=50, ax=axes[0, 1], color="#264653"); axes[0, 1].set_title("Average daily rate (capped at 400 for display)")
sns.histplot((eda["stays_in_weekend_nights"] + eda["stays_in_week_nights"]).clip(upper=15), bins=15, ax=axes[0, 2], color="#264653"); axes[0, 2].set_title("Total nights (capped at 15)")
sns.countplot(data=eda, x="adults", ax=axes[1, 0], color="#264653"); axes[1, 0].set_title("Adults")
sns.countplot(data=eda, x="total_of_special_requests", ax=axes[1, 1], color="#264653"); axes[1, 1].set_title("Special requests")
sns.countplot(data=eda, x="previous_cancellations", ax=axes[1, 2], color="#264653"); axes[1, 2].set_title("Previous cancellations")
axes[1, 2].set_xlim(-0.5, 6.5)
plt.tight_layout(); savefig("eda_univariate_numeric.png")
''')
code(r'''
cat_cols = ["hotel", "meal", "market_segment", "distribution_channel", "deposit_type", "customer_type"]
fig, axes = plt.subplots(2, 3, figsize=(16, 8))
for ax, col in zip(axes.ravel(), cat_cols):
    order = eda[col].value_counts().index
    sns.countplot(data=eda, y=col, order=order, ax=ax, color="#264653")
    ax.set_title(col); ax.set_ylabel("")
plt.tight_layout(); savefig("eda_univariate_categorical.png")

print("Top 10 countries by number of bookings:")
eda["country"].value_counts().head(10)
''')
md(r'''
**Observations:** about 74 % of bookings are short (1-4 nights) and 74 % are for exactly 2 adults; half have no special requests and 98 % have no previous cancellation. About 59 % come through online travel agencies (`Online TA`), 99 % use the `No Deposit` option and 82 % are `Transient` customers. The city hotel receives roughly 1.6 times as many bookings as the resort. Portugal (PRT) is by far the most common country.

**Outliers.** The IQR rule (values beyond 1.5 x IQR from the quartiles) flags how many extreme values each numeric column has:
''')
code(r'''
def iqr_outliers(s):
    q1, q3 = s.quantile([.25, .75]); iqr = q3 - q1
    return int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())

cols = ["lead_time", "adr", "stays_in_week_nights", "stays_in_weekend_nights", "previous_cancellations"]
pd.DataFrame({"IQR outliers": {c: iqr_outliers(eda[c]) for c in cols},
              "percent of rows": {c: round(100 * iqr_outliers(eda[c]) / len(eda), 2) for c in cols},
              "max value": {c: eda[c].max() for c in cols}})
''')
md(r'''
Many of these "outliers" are real (long lead times and expensive suites exist), so we do **not** delete them. Instead the pipeline applies fixed, domain-based caps (for example ADR is capped at 500) so that a handful of extreme values cannot dominate the scaled features (see `OUTLIER_CAPS` in `src/config.py`). Only clearly impossible rows (negative ADR, ADR > 1000, more than 10 adults, zero guests or zero nights) are removed.

### 3.2 Bivariate analysis - each factor against cancellation
Each bar shows the **cancellation rate** for a group and `n` is the number of bookings in that group.
''')
code(r'''
fig_defs = [
    ("lead_time_group", "Lead time vs cancellation", LEAD_LABELS, "eda_lead_time.png"),
    ("deposit_type", "Deposit type vs cancellation", None, "eda_deposit_type.png"),
    ("hotel", "Hotel type vs cancellation", None, "eda_hotel.png"),
    ("customer_type", "Customer type vs cancellation", None, "eda_customer_type.png"),
]
for col, title, order, fname in fig_defs:
    d = cancel_rate_by(eda, col, order)
    display(d.assign(cancel_rate=(d["cancel_rate"] * 100).round(1)).rename(columns={"cancel_rate": "cancel_rate_%"}))
    plots.plot_cancel_rate(d, col, title); savefig(fname); plt.show()
''')
code(r'''
seg = cancel_rate_by(eda[eda["market_segment"] != "Undefined"], "market_segment")
display(seg.assign(cancel_rate=(seg["cancel_rate"] * 100).round(1)).rename(columns={"cancel_rate": "cancel_rate_%"}))
plots.plot_cancel_rate(seg, "market_segment", "Market segment vs cancellation", rotate=30); savefig("eda_market_segment.png"); plt.show()

eda["prev_cancel_group"] = pd.cut(eda["previous_cancellations"], [-1, 0, 1, 2, 100], labels=["0", "1", "2", "3+"]).astype(str)
prev = cancel_rate_by(eda, "prev_cancel_group", ["0", "1", "2", "3+"])
display(prev.assign(cancel_rate=(prev["cancel_rate"] * 100).round(1)).rename(columns={"cancel_rate": "cancel_rate_%"}))
plots.plot_cancel_rate(prev, "prev_cancel_group", "Previous cancellations vs cancellation"); savefig("eda_previous_cancellations.png"); plt.show()
''')
code(r'''
adr_tbl = cancel_rate_by(eda, "adr_group", ADR_LABELS)
display(adr_tbl.assign(cancel_rate=(adr_tbl["cancel_rate"] * 100).round(1)).rename(columns={"cancel_rate": "cancel_rate_%"}))

fig, axes = plt.subplots(1, 2, figsize=(14, 4.5))
sns.boxplot(data=eda, x="is_canceled", y="adr", ax=axes[0], palette=["#2a9d8f", "#e76f51"], showfliers=False)
axes[0].set_xticklabels(["Not canceled", "Canceled"]); axes[0].set_title("ADR by cancellation (outliers hidden)"); axes[0].set_xlabel("")
sns.boxplot(data=eda, x="is_canceled", y="lead_time", ax=axes[1], palette=["#2a9d8f", "#e76f51"])
axes[1].set_xticklabels(["Not canceled", "Canceled"]); axes[1].set_title("Lead time by cancellation"); axes[1].set_xlabel("")
plt.tight_layout(); savefig("eda_adr_leadtime_boxplots.png")
''')
md(r'''
### 3.3 Multivariate analysis - several variables together
''')
code(r'''
num_for_corr = ["is_canceled", "lead_time", "adr", "adults", "children", "stays_in_weekend_nights",
                "stays_in_week_nights", "is_repeated_guest", "previous_cancellations",
                "required_car_parking_spaces", "total_of_special_requests"]
corr = eda[num_for_corr].corr()
plt.figure(figsize=(9, 7))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, square=True, cbar_kws={"shrink": .8})
plt.title("Correlation matrix of numeric variables"); plt.tight_layout(); savefig("eda_correlation.png")

print("Correlation with is_canceled:")
corr["is_canceled"].drop("is_canceled").sort_values(ascending=False).round(3)
''')
code(r'''
pivot = (eda[eda["market_segment"].isin(["Online TA", "Offline TA/TO", "Direct", "Groups", "Corporate"])]
         .pivot_table(index="market_segment", columns="lead_time_group", values="is_canceled", aggfunc="mean")[LEAD_LABELS])
plt.figure(figsize=(9, 4.5))
sns.heatmap(pivot, annot=True, fmt=".0%", cmap="YlOrRd", cbar_kws={"label": "Cancellation rate"})
plt.title("Cancellation rate: market segment x lead time"); plt.ylabel(""); plt.xlabel("")
plt.tight_layout(); savefig("eda_segment_leadtime_heatmap.png")

pivot2 = eda.pivot_table(index="hotel", columns="deposit_type", values="is_canceled", aggfunc="mean")
print("Cancellation rate by hotel x deposit type:"); (pivot2 * 100).round(1)
''')
md(r'''
**Reading the multivariate plots:** the correlation matrix only captures *linear* relationships between numbers (note the strong negative value for parking, which turns out to be a data warning - see Section 4.1). In the heat-map the cancellation rate rises with lead time in `Online TA`, `Offline TA/TO`, `Direct` and `Groups` bookings (the `Corporate` row is irregular because it has few bookings at long lead times). `Online TA` is the riskiest segment at every lead time longer than a week, with one small exception: corporate bookings made 6-12 months ahead. This kind of **interaction** (the effect of lead time depends on the channel) is one reason tree-based models usually beat a straight-line model here.

### 3.4 Business insights from the analysis
The statements below are computed directly from the data, so they stay correct if the data changes.
''')
code(r'''
r = lambda col, val: eda.loc[eda[col] == val, "is_canceled"].mean()
short, long_ = r("lead_time_group", "0-7 d"), r("lead_time_group", "181-365 d")
prev1 = eda.loc[eda["previous_cancellations"] > 0, "is_canceled"].mean()
prev0 = eda.loc[eda["previous_cancellations"] == 0, "is_canceled"].mean()
nr = eda[eda["deposit_type"] == "Non Refund"]
online, direct, corp = r("market_segment", "Online TA"), r("market_segment", "Direct"), r("market_segment", "Corporate")
city, resort = r("hotel", "City Hotel"), r("hotel", "Resort Hotel")
req0 = eda.loc[eda["total_of_special_requests"] == 0, "is_canceled"].mean()
req1 = eda.loc[eda["total_of_special_requests"] >= 1, "is_canceled"].mean()
has_park = eda["required_car_parking_spaces"] > 0

print(f"1. LEAD TIME: bookings made 0-7 days ahead cancel {short:.1%} of the time vs {long_:.1%} for 181-365 days ahead.")
print(f"2. HISTORY: guests with a previous cancellation cancel {prev1:.1%} of the time vs {prev0:.1%} for guests without one.")
print(f"3. CHANNEL: Online TA bookings cancel {online:.1%} vs {direct:.1%} for Direct and {corp:.1%} for Corporate bookings.")
print(f"4. ENGAGEMENT: guests with >=1 special request cancel {req1:.1%} vs {req0:.1%} with none.")
print(f"5. DEPOSIT (careful!): 'Non Refund' bookings cancel {nr['is_canceled'].mean():.1%} but make up only {len(nr) / len(eda):.1%} of bookings. "
      f"This is a surprising pattern in this dataset and is concentrated in a few segments/countries, "
      f"so it should NOT be read as 'deposits cause cancellations'.")
print(f"6. HOTEL: the City Hotel cancels {city:.1%} vs {resort:.1%} for the Resort Hotel.")
print(f"7. DATA WARNING: {has_park.sum():,} bookings have a parking space and {int(eda.loc[has_park, 'is_canceled'].sum())} of them were canceled "
      f"(vs {eda.loc[~has_park, 'is_canceled'].mean():.1%} for the rest). That is not realistic behaviour - see the leakage section.")
''')
md(r'''
**Summary of insights**
1. **Long lead times are risky.** The longer the gap between booking and arrival, the more likely the guest is to cancel - plans change, or the guest keeps shopping for better offers.
2. **Past behaviour predicts future behaviour.** A previous cancellation is one of the clearest warning signs.
3. **Sales channel matters.** Online travel-agency bookings (often free to cancel) are much more fragile than direct or corporate bookings.
4. **Engaged guests stay.** Guests who make special requests cancel noticeably less often (about 22 % vs 34 % with no requests), and the rate keeps falling as the number of requests grows.
5. **Be careful with suspiciously perfect patterns.** No booking with a parking space was ever canceled - a warning sign of leakage, not a business insight (Section 4.1).
6. **Deposits need careful interpretation.** The dataset shows a very high cancellation rate for non-refundable bookings. That is an association inside a small, special group of bookings, not proof that charging deposits increases cancellations - so deposit policy should be tested (for example with an A/B test) rather than assumed.
''')

# =============================================================================
# 4. Preprocessing
# =============================================================================
md(r'''
## 4. Data Preprocessing
### 4.1 Data leakage
**Data leakage** means using information in the features that would *not be available when the prediction is needed*, or that directly reveals the answer. It produces unrealistically good scores that collapse in real life.

In this dataset `reservation_status` ("Canceled", "Check-Out", "No-Show") is simply the outcome written in words:
''')
code(r'''
display(pd.crosstab(raw["reservation_status"], raw["is_canceled"]))
print("Columns removed to prevent leakage:", cfg.LEAKAGE_COLUMNS)
print("\nColumns deliberately NOT used (known late, ID codes, or not in the booking form):")
print(cfg.EXCLUDED_COLUMNS)
''')
md(r'''
`reservation_status` perfectly separates the classes (every "Canceled"/"No-Show" row is `is_canceled = 1`), and `reservation_status_date` is the date of that outcome, so **both are removed**. We also leave out `assigned_room_type`, `booking_changes` and `days_in_waiting_list` because they are only fully known late in the booking life-cycle, and `agent`/`company` because they are anonymised IDs.

#### A second, subtler leakage suspect: `required_car_parking_spaces`
Look at the cancellation rate for bookings that have a parking space:
''')
code(r'''
has_parking = eda["required_car_parking_spaces"] > 0
print(pd.DataFrame({
    "bookings": [int(has_parking.sum()), int((~has_parking).sum())],
    "canceled": [int(eda.loc[has_parking, "is_canceled"].sum()), int(eda.loc[~has_parking, "is_canceled"].sum())],
    "cancel_rate": [eda.loc[has_parking, "is_canceled"].mean(), eda.loc[~has_parking, "is_canceled"].mean()],
}, index=["parking space requested", "no parking space"]).round(4))
''')
md(r'''
**Zero** cancellations among thousands of bookings is not realistic guest behaviour - roughly 30 % of the other bookings cancel. The most likely explanation is that the hotel system fills in this field only once the guest has actually stayed (or resets it when a booking is canceled), so it is recorded *after* the outcome. That is **target leakage**: the model would learn "parking = never cancels", which cannot be known for a genuinely new booking. We measure the effect in Section 4.3 and **exclude the column** (`USE_PARKING_FEATURE = False` in `src/config.py`). This is a deliberate deviation from the usual list of booking-form fields.

### 4.2 Cleaning rules (done before the split)
These are fixed rules that look at one row at a time - they do not compute any average or statistic from the data, so they cannot leak information:
''')
code(r'''
pd.Series(clean_report, name="rows").to_frame()
''')
md(r'''
### 4.3 Train / test split **before** fitting any transformer
The test set plays the role of "future bookings". It must not influence *anything* we learn - not the imputation values, not the scaling, not the encoder categories, not the model, not the tuning, not the threshold. So we split first (80 % train / 20 % test, stratified so both parts keep the same cancellation rate) and later fit every transformer on the training part only.
''')
code(r'''
X_train, X_test, y_train, y_test = split_data(clean)
print("Train:", X_train.shape, "| Test:", X_test.shape)
print(f"Cancellation rate  train = {y_train.mean():.4f}   test = {y_test.mean():.4f}")
print("\nModel input columns:", list(X_train.columns))
''')
code(r'''
from src.analysis import parking_leakage_check
leak = parking_leakage_check(clean, X_train, X_test, y_train, y_test)
print(f"Same Random Forest, same split, test ROC-AUC WITH the parking column   : {leak['test_roc_auc_with_parking']:.4f}")
print(f"Same Random Forest, same split, test ROC-AUC WITHOUT the parking column: {leak['test_roc_auc_without_parking']:.4f}")
print(f"Score inflated by the leaking column: {leak['test_roc_auc_with_parking'] - leak['test_roc_auc_without_parking']:+.4f} ROC-AUC")
''')
md(r'''
Dropping the column lowers the score - which is exactly the point: the higher score was not real skill. All models below are trained **without** `required_car_parking_spaces`.

### 4.4 Feature engineering and preprocessing pipeline
`add_features()` (in `src/features.py`) is the first step of the pipeline. It:
* fills missing `children` with 0 and missing `country` with "Unknown", and treats meal "Undefined" as "SC";
* caps extreme values with fixed domain limits;
* creates new features: `total_nights`, `total_guests`, `has_children`, `adr_per_person`, `weekend_share`, `has_previous_cancellation`, `has_special_requests`.

Then a `ColumnTransformer` imputes missing numbers (median), optionally scales numbers (only for Logistic Regression), and one-hot encodes categories (rare countries are grouped as "infrequent", and unseen categories are handled safely).
''')
code(r'''
features_demo = add_features(X_train.head(5))
features_demo[["lead_time", "adr", "total_nights", "total_guests", "adr_per_person", "weekend_share", "has_special_requests"]]
''')
code(r'''
demo = make_pipeline(get_models()["Random Forest"].named_steps["model"], scale_numeric=False)
print(demo)
demo[:-1].fit(X_train)                       # fit ONLY the preprocessing on TRAIN data
Xt = demo[:-1].transform(X_train)
print("\nTransformed training matrix:", Xt.shape)
print("First 10 feature names:", list(demo.named_steps["preprocess"].get_feature_names_out()[:10]))
''')

# =============================================================================
# 5. Models
# =============================================================================
md(r'''
## 5. Machine-Learning Models
We start with a **baseline** (always predict the majority class) to know what "no skill" looks like, then train the four required algorithms. Every model is wrapped in the same pipeline, so the comparison is fair.

### 5.1 The algorithms in simple words
| Algorithm | How it works (simple English) | Strengths | Weaknesses |
|---|---|---|---|
| **Logistic Regression** | Gives each feature a weight, adds them up and squeezes the sum into a probability between 0 and 1 (an S-shaped curve). | Fast, simple, easy to interpret, gives probabilities. | Can only draw *straight* decision boundaries, so it misses interactions (e.g. lead time matters differently by channel). Needs scaled inputs. |
| **Decision Tree** | Asks a series of yes/no questions ("lead time > 100? deposit = Non Refund?") that split the bookings into ever purer groups. | Easy to visualise and explain, handles mixed data and interactions, no scaling needed. | One tree easily over-fits (memorises the training data) and is unstable. |
| **Random Forest** | Trains many trees on random samples of rows and features and averages their votes. | Much more accurate and stable than one tree, robust to noise and outliers, little tuning needed. | Harder to interpret, bigger model file, slower than simple models. |
| **Gradient Boosting** | Builds trees one after another; each new tree focuses on the mistakes of the previous ones. | Often the most accurate on tabular data, flexible. | Slower to train, more sensitive to hyper-parameters, can over-fit if not tuned. |

### 5.2 Compare all models with 5-fold cross-validation (training data only)
Cross-validation splits the training set into 5 parts, trains on 4 and validates on 1, rotating 5 times. The average score is a more reliable estimate than a single split, and **we never touch the test set to pick the model**.
''')
code(r'''
cv = StratifiedKFold(n_splits=cfg.CV_FOLDS_COMPARE, shuffle=True, random_state=cfg.RANDOM_STATE)
scoring = {"roc_auc": "roc_auc", "pr_auc": "average_precision", "f1": "f1",
           "precision": "precision", "recall": "recall", "accuracy": "accuracy"}
models = get_models()
rows, test_proba = [], {}
for name, pipe in models.items():
    res = cross_validate(pipe, X_train, y_train, cv=cv, scoring=scoring, n_jobs=1)
    row = {"model": name}
    for m in scoring:
        row[f"cv_{m}_mean"], row[f"cv_{m}_std"] = res[f"test_{m}"].mean(), res[f"test_{m}"].std()
    fitted = clone(pipe).fit(X_train, y_train)            # train on the full training set
    proba = fitted.predict_proba(X_test)[:, 1]            # make predictions on the test set
    test_proba[name] = proba
    tm = metrics_at_threshold(y_test, proba, 0.5)
    row.update({f"test_{k}": tm[k] for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]})
    rows.append(row)
    print(f"{name:<28} CV ROC-AUC = {row['cv_roc_auc_mean']:.4f} +/- {row['cv_roc_auc_std']:.4f}   CV F1 = {row['cv_f1_mean']:.4f}")
comparison = pd.DataFrame(rows)
''')
code(r'''
cols = ["model", "cv_accuracy_mean", "cv_precision_mean", "cv_recall_mean", "cv_f1_mean", "cv_roc_auc_mean", "cv_pr_auc_mean"]
display(comparison[cols].round(4).rename(columns=lambda c: c.replace("cv_", "CV ").replace("_mean", "")))
print("Same models fitted on the full training set and scored on the TEST set (threshold 0.5) - for information only:")
comparison[["model", "test_accuracy", "test_precision", "test_recall", "test_f1", "test_roc_auc"]].round(4)
''')
code(r'''
plots.plot_model_comparison(comparison); savefig("model_comparison_cv.png"); plt.show()
plots.plot_roc_curves(y_test, {k: v for k, v in test_proba.items() if not k.startswith("Baseline")}); savefig("roc_all_models.png")
''')
md(r'''
### 5.3 Choosing the best model
We pick the model with the best **cross-validated ROC-AUC** (it measures how well the model *ranks* risky bookings above safe ones and does not depend on a threshold), and look at F1 / precision / recall alongside it. Accuracy is *not* used for the decision.
''')
code(r'''
candidates = comparison[~comparison["model"].str.startswith("Baseline")]
best_name = candidates.sort_values("cv_roc_auc_mean", ascending=False).iloc[0]["model"]
print("Best algorithm by cross-validated ROC-AUC:", best_name)
''')
md(r'''
**Why Random Forest wins here:** the cancellation behaviour depends on *combinations* of factors (channel x lead time x country x requests). Logistic Regression cannot represent such interactions, a single tree is too unstable, and Random Forest captures interactions while averaging away noise. Gradient Boosting is competitive, but with the settings tried here it did not beat the Random Forest and takes noticeably longer to train.

## 6. Model Optimisation
We tune the selected algorithm with `RandomizedSearchCV` (3-fold CV, ROC-AUC) on the **training data only**. Randomised search tries a fixed number of random combinations, which is far cheaper than trying every combination of a grid.

The tuning is the slowest step of the project (several minutes), so by default this notebook loads the results saved by `python -m src.train`. Set `RUN_TUNING = True` to repeat the search here.
''')
code(r'''
RUN_TUNING = False   # set True to re-run the randomised search inside the notebook (takes several minutes)

meta = json.load(open(cfg.METADATA_PATH))
if RUN_TUNING:
    search = RandomizedSearchCV(models[best_name], get_param_distributions(best_name), n_iter=cfg.N_ITER_SEARCH,
                                scoring="roc_auc", cv=StratifiedKFold(cfg.CV_FOLDS_TUNING, shuffle=True, random_state=cfg.RANDOM_STATE),
                                random_state=cfg.RANDOM_STATE, n_jobs=1, verbose=1).fit(X_train, y_train)
    print("Best params:", search.best_params_, "| CV ROC-AUC:", round(search.best_score_, 4))
else:
    print("Best params (saved by train.py):", meta["best_params"])
    print("Best CV ROC-AUC (3-fold)       :", round(meta["tuning_cv_roc_auc"], 4))

tuning = pd.read_csv(cfg.REPORTS_DIR / "tuning_results.csv")
tuning.round(4)
''')
md(r'''
**Did tuning help?** To answer fairly we score the *untuned* Random Forest with exactly the same 3 folds used by the search:
''')
code(r'''
cv3 = StratifiedKFold(cfg.CV_FOLDS_TUNING, shuffle=True, random_state=cfg.RANDOM_STATE)
untuned = cross_validate(models[best_name], X_train, y_train, cv=cv3, scoring="roc_auc", n_jobs=1)["test_score"]
print(f"Untuned {best_name}: CV ROC-AUC (3-fold) = {untuned.mean():.4f}")
print(f"Tuned   {best_name}: CV ROC-AUC (3-fold) = {meta['tuning_cv_roc_auc']:.4f}")
print(f"Difference: {meta['tuning_cv_roc_auc'] - untuned.mean():+.4f}")
''')
md(r'''
**Honest reading:** the tuned forest is better by only about 0.0003 ROC-AUC, far smaller than the fold-to-fold noise (about 0.002). In practice tuning gave **no meaningful gain**: the sensible default Random Forest was already close to the best this feature set can achieve. This is a common and useful finding - for this data, better *features* (for example arrival date or room information) are likely to help more than more tuning. The training script keeps the tuned model only when it scores higher than the untuned one under identical folds, which it does here (barely), so the tuned model is the saved one. Its settings (`max_depth = 18`, `min_samples_leaf = 5`) also regularise the forest.

## 7. Threshold Analysis
A classifier outputs a **probability**; turning it into "Canceled / Not Canceled" needs a **threshold**. The default 0.5 is not automatically best, especially with imbalanced classes. Lowering the threshold catches more real cancellations (higher recall) but raises false alarms (lower precision).

To choose the threshold **without touching the test set**, `train.py` produced *out-of-fold* predictions on the training data (each booking is scored by a model that never saw it) and picked the threshold with the best F1-score.
''')
code(r'''
thr = pd.read_csv(cfg.REPORTS_DIR / "threshold_analysis.csv")
chosen = meta["threshold"]
plots.plot_threshold_analysis(thr, chosen); savefig("threshold_analysis.png"); plt.show()
thr[thr["threshold"].isin([0.20, 0.25, 0.30, chosen, 0.35, 0.40, 0.50, 0.60])].drop_duplicates("threshold")[
    ["threshold", "precision", "recall", "f1", "accuracy"]].round(3)
''')
md(r'''
**Business view of the trade-off**
* **False negative** (model says "will stay", guest cancels): the room stays empty and the revenue is lost; the hotel also could have resold it or overbooked.
* **False positive** (model says "will cancel", guest shows up): if the hotel overbooks because of this prediction, it may have to relocate a paying guest - an expensive, reputation-damaging event.

Which mistake costs more depends on the hotel. The table below uses **illustrative cost ratios (assumptions, not data)** to show how the best threshold moves:
''')
code(r'''
# ASSUMPTION: relative cost of a missed cancellation (FN) vs a false alarm (FP). Change these to your hotel's real numbers.
ratios = {"FN costs the same as FP (1:1)": (1, 1), "FN costs 2x FP (2:1)": (2, 1),
          "FN costs 3x FP (3:1)": (3, 1), "FP costs 2x FN (1:2)": (1, 2)}
out = []
for label, (c_fn, c_fp) in ratios.items():
    cost = thr["fn"] * c_fn + thr["fp"] * c_fp
    best = thr.loc[cost.idxmin()]
    out.append({"assumption": label, "best_threshold": best["threshold"], "precision": round(best["precision"], 3), "recall": round(best["recall"], 3)})
pd.DataFrame(out)
''')
md(r'''
**Decision.** Without hotel-specific costs we use the threshold that maximises **F1** (the balance of precision and recall): **0.31**. A hotel that fears empty rooms more than relocations would lower it; one that fears relocations more would raise it. The Streamlit app reads the threshold from the metadata file, so changing it is a one-line change in the training script.

## 8. Final Evaluation on the Untouched Test Set
This is the **first and only time** the final model sees the test set.
''')
code(r'''
final_model = joblib.load(cfg.MODEL_PATH)             # the saved pipeline used by the app
proba = final_model.predict_proba(X_test)[:, 1]
m = metrics_at_threshold(y_test, proba, chosen)
m50 = metrics_at_threshold(y_test, proba, 0.5)
results = pd.DataFrame({"threshold 0.50": m50, f"threshold {chosen:.2f} (chosen)": m}).loc[
    ["accuracy", "precision", "recall", "f1", "roc_auc", "pr_auc"]].round(4)
display(results)

# consistency check: the saved model reproduces the numbers written by train.py
assert abs(m["f1"] - meta["test_metrics_final"]["f1"]) < 1e-9
print("Check passed: notebook results match the training script.")
''')
code(r'''
y_pred = (proba >= chosen).astype(int)
print(classification_report(y_test, y_pred, target_names=["Not Canceled", "Canceled"], digits=4))
cm_default = confusion_matrix(y_test, (proba >= 0.5).astype(int))
cm_final = confusion_matrix(y_test, y_pred)
plots.plot_confusion_matrices({"Threshold = 0.50": cm_default, f"Chosen threshold = {chosen:.2f}": cm_final})
savefig("confusion_matrices.png"); plt.show()
''')
code(r'''
all_models = {k: v for k, v in test_proba.items() if k in ("Logistic Regression", "Decision Tree", "Random Forest", "Gradient Boosting")}
all_models["Tuned Random Forest (final)"] = proba
plots.plot_roc_curves(y_test, all_models); savefig("roc_curves.png")
''')
md(r'''
### What each metric means for a hotel
| Metric | Plain meaning | Hotel interpretation |
|---|---|---|
| **Accuracy** | Share of all predictions that are right. | Overall hit rate. Misleading alone because most bookings are not canceled. |
| **Precision** (of "Canceled") | Of the bookings flagged as "will cancel", how many really cancel. | When the system warns about a booking, how often is the warning right? Low precision = many false alarms, e.g. needless reminders or unnecessary overbooking risk. |
| **Recall** (of "Canceled") | Of all bookings that really cancel, how many we caught. | Share of future empty rooms we saw coming. Low recall = lost revenue that nobody anticipated. |
| **F1-score** | Harmonic mean of precision and recall. | One number balancing "right when we warn" and "catch most cancellations". |
| **ROC-AUC** | Probability that a random canceled booking gets a higher risk score than a random non-canceled one (0.5 = coin flip, 1 = perfect). | How well the model *ranks* risk, independent of the threshold. |
| **Confusion matrix** | Counts of true/false positives and negatives. | TP = cancellations predicted, FP = false alarms, FN = surprise cancellations, TN = correctly expected stays. |

Both kinds of error cost money, which is why we look at precision **and** recall and tune the threshold rather than relying on accuracy.

## 9. Error Analysis - where does the model go wrong?
''')
code(r'''
errs = error_analysis(X_test, y_test, proba, chosen)
for key in ["lead_time_group", "market_segment", "deposit_type", "hotel"]:
    print(f"--- errors by {key} ---")
    display(pd.DataFrame(errs[key])[[key, "bookings", "actual_cancel_rate", "error_rate", "false_negatives", "false_positives", "missed_cancel_share"]])
''')
code(r'''
res = X_test.copy(); res["actual"] = y_test.values; res["p_cancel"] = proba; res["pred"] = y_pred
print("Most confident FALSE NEGATIVES (model sure the guest stays, but the guest canceled):")
display(res[(res.actual == 1) & (res.pred == 0)].sort_values("p_cancel").head(6)[
    ["hotel", "lead_time", "market_segment", "country", "deposit_type", "total_of_special_requests", "adr", "p_cancel"]].round(3))
print("Most confident FALSE POSITIVES (model sure the guest cancels, but the guest stayed):")
display(res[(res.actual == 0) & (res.pred == 1)].sort_values("p_cancel", ascending=False).head(6)[
    ["hotel", "lead_time", "market_segment", "country", "deposit_type", "total_of_special_requests", "adr", "p_cancel"]].round(3))
''')
md(r'''
**Where the model struggles** (numbers from the tables above)
* **Last-minute bookings (0-7 days):** cancellations are rare here (about 9 % of bookings), but the model catches only about one in five of them (it misses about 80 % of the cancellations in this group). A short lead time is such a strong "will stay" signal that the exceptions are almost impossible to foresee from the available fields.
* **Online travel agencies:** this segment has the highest error rate and produces about three quarters of all the model's mistakes (both false alarms and missed cancellations), simply because it is the largest segment and its guests behave in the most mixed way.
* **Mid lead times (8-180 days):** error rates are highest here (roughly 22-26 %), because cancellation is genuinely a toss-up for many of these bookings.
* **Small segments** such as `Complementary` or `Aviation` have too few bookings for reliable conclusions.

Information the model never sees - the guest's personal circumstances, a cheaper competitor offer, the weather - explains part of the remaining error; richer data (arrival season, room type, payment details) could reduce it.

## 10. Feature Importance and Business Insights
Three complementary views:
1. **Built-in importance** of the Random Forest (how much each feature reduced impurity across trees) - fast but biased towards features with many values.
2. **Permutation importance** - shuffle one raw column of the test set and measure how much ROC-AUC drops. A bigger drop means the model relies on that column more. It is computed on the raw input columns, so the result is easy to explain.
3. **SHAP** (optional) - shows direction and size of each feature's effect.
''')
code(r'''
native = aggregate_native_importance(final_model)
perm = permutation_importance_raw(final_model, X_test, y_test, n_repeats=5, sample=10000)
display(perm.round(4))
plots.plot_importance(perm, "importance_mean", "Permutation importance (drop in ROC-AUC, test set)", err_col="importance_std")
savefig("permutation_importance.png"); plt.show()
plots.plot_importance(native, "importance", "Built-in Random Forest importance (one-hot columns summed per feature)")
savefig("feature_importance.png")
''')
code(r'''
try:
    import shap
    sample = X_test.sample(300, random_state=cfg.RANDOM_STATE)
    Xs = final_model[:-1].transform(sample)
    names = final_model.named_steps["preprocess"].get_feature_names_out()
    sv = shap.TreeExplainer(final_model.named_steps["model"]).shap_values(Xs)
    sv = sv[1] if isinstance(sv, list) else (sv[:, :, 1] if getattr(sv, "ndim", 2) == 3 else sv)
    shap.summary_plot(sv, Xs, feature_names=names, show=False, max_display=15)
    plt.tight_layout(); savefig("shap_summary.png")
except ImportError:
    print("SHAP is not installed in this environment (optional). Install it with `pip install shap` and re-run this cell.")
''')
md(r'''
### Explained in business language
* **Market segment, country and lead time** are the three things the model relies on most. *Who* is booking (and through which channel), *where from*, and *how far ahead* describe most of the cancellation risk.
* **Special requests** are the next strongest signal: guests who personalise their stay are committed, so they cancel less. (Parking requests were excluded because of leakage - Section 4.1.)
* **Price (ADR)** and **customer type** come next: higher-priced bookings are cancelled more often in this data, and transient customers more than contract or group customers.
* **Previous cancellations** matter a lot *when present* (68 % of such guests cancel again), but because few guests have a record, the column contributes less to the overall score.
* **Deposit type** ranks lower than expected in permutation importance, because the few `Non Refund` bookings are largely identified by *other* columns (segment, country) as well - shuffling `deposit_type` alone costs little. Importance does not mean causation.

> **Note on interpretation:** feature importance describes what the *model* uses, not what *causes* cancellations. Use it to prioritise ideas, then test the ideas (e.g. with pilots) before changing policies.

### Practical recommendations for hotel management
1. **Identify high-risk bookings automatically.** Score every new booking, flag those above the threshold (0.31) and review them first - especially online-agency bookings made more than ~3 months ahead with no special requests.
2. **Reconfirm before arrival.** For high-risk, long-lead bookings send a reminder/reconfirmation message 2-4 weeks before arrival; a cancellation signalled early can still be resold.
3. **Test deposit and cancellation policies rather than assume.** Pilot stricter terms (partial deposit, shorter free-cancellation window) on the riskiest channels and measure the effect; the data alone cannot say that deposits reduce cancellations.
4. **Manage overbooking with probabilities, not guesses.** Expected cancellations for a date = the sum of the booking probabilities. Overbook by a fraction of that number, keeping a safety margin, and choose the threshold according to the relative cost of an empty room vs a relocated guest (Section 7).
5. **Reward commitment.** Encourage guests to personalise their stay (special requests, packages) at booking time, and use direct-booking incentives - both are associated with fewer cancellations.
6. **Keep the model fresh.** Retrain regularly with new bookings, and monitor precision and recall over time.

## 11. Save the Model and Test It Like the App Does
The saved file is the **entire pipeline** (feature engineering + preprocessing + Random Forest), so the Streamlit app only has to feed it a raw booking row.
''')
code(r'''
import os
print("Model file:", cfg.MODEL_PATH.relative_to(ROOT), f"({os.path.getsize(cfg.MODEL_PATH) / 1e6:.1f} MB)")
print("Pipeline steps:", [name for name, _ in final_model.steps])

from src.predict import predict_booking, recommendation
example = {"hotel": "City Hotel", "lead_time": 150, "adults": 2, "children": 0, "stays_in_weekend_nights": 1,
           "stays_in_week_nights": 3, "meal": "BB", "country": "PRT", "market_segment": "Online TA",
           "distribution_channel": "TA/TO", "is_repeated_guest": 0, "previous_cancellations": 0,
           "deposit_type": "No Deposit", "customer_type": "Transient", "adr": 105.0,
           "total_of_special_requests": 0}
pred = predict_booking(final_model, example, chosen)
print(f"\nExample booking -> canceled = {pred.is_canceled}, probability = {pred.probability:.1%}, risk = {pred.risk_level}")
for tip in recommendation(pred, example):
    print(" -", tip)
''')
md(r'''
## 12. Conclusion and Future Improvements
**What we built:** a leakage-free, reproducible pipeline that compares a baseline and four algorithms with cross-validation, tunes the best one, chooses a decision threshold on training data only, and evaluates once on an untouched test set. The final model and the Streamlit app share the exact same preprocessing code.

**Main results** (see the output of Section 8): the tuned Random Forest reaches a test ROC-AUC of about 0.87 (0.866); with the F1-optimised threshold of 0.31 it finds roughly three out of four real cancellations (recall ~0.76) at a precision of ~0.59. An earlier version that used the leaking parking column scored about 0.88 - the lower, honest number is the one to trust.

**Limitations**
* The data comes from two hotels in Portugal in 2015-2017, so results may not transfer to other markets or periods.
* The model uses only information available in the booking form. Tuning gave very little extra accuracy, so the feature set, not the algorithm, is the main limit.
* Importance and insights show *association*, not cause.
* The 0.31 threshold ignores real hotel costs; the cost table in Section 7 is only an illustration.

**Future improvements**
* Add arrival date/season, room type, payment method and booking-channel details; try a time-based split to mimic real deployment.
* Try gradient-boosting libraries (XGBoost / LightGBM) with larger searches, and probability calibration.
* Use real revenue and relocation costs to choose the threshold.
* Add SHAP explanations to the app, monitor model drift, and retrain regularly.
''')


# =============================================================================
# Mini notebook executor (so outputs are stored in the .ipynb without Jupyter)
# =============================================================================
def _cell_id() -> str:
    return uuid.uuid4().hex[:8]


def _text_lines(s: str) -> list[str]:
    lines = s.splitlines(keepends=True)
    return lines or [""]


def execute_cells() -> list[dict]:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    warnings.filterwarnings("ignore")
    ns: dict = {"__name__": "__main__"}
    outputs_list: list[dict] = []
    count = 0
    t_all = time.time()

    for i, (kind, src) in enumerate(CELLS):
        cell = {"id": _cell_id(), "metadata": {}, "source": _text_lines(src)}
        if kind == "markdown":
            cell["cell_type"] = "markdown"
            outputs_list.append(cell)
            continue

        count += 1
        cell.update({"cell_type": "code", "execution_count": count, "outputs": []})
        outs = cell["outputs"]
        buf = io.StringIO()

        def flush_stream():
            if buf.getvalue():
                outs.append({"output_type": "stream", "name": "stdout", "text": _text_lines(buf.getvalue())})
                buf.seek(0)
                buf.truncate(0)

        def rich(obj):
            flush_stream()
            data = {"text/plain": _text_lines(repr(obj))}
            if hasattr(obj, "_repr_html_"):
                html = obj._repr_html_()
                if html:
                    data["text/html"] = _text_lines(html)
            outs.append({"output_type": "display_data", "data": data, "metadata": {}})

        def display(*objs):
            for o in objs:
                rich(o)

        ns["display"] = display
        t0 = time.time()
        try:
            tree = ast.parse(src)
            last = None
            if tree.body and isinstance(tree.body[-1], ast.Expr):
                last = ast.Expression(tree.body.pop().value)
            with contextlib.redirect_stdout(buf):
                exec(compile(tree, f"<cell {i}>", "exec"), ns)
                val = eval(compile(last, f"<cell {i}>", "eval"), ns) if last is not None else None
            if val is not None:
                rich(val)
            flush_stream()
            for num in plt.get_fignums():
                fig = plt.figure(num)
                png = io.BytesIO()
                fig.savefig(png, format="png", dpi=110, bbox_inches="tight")
                outs.append({"output_type": "display_data", "metadata": {},
                             "data": {"image/png": base64.b64encode(png.getvalue()).decode(),
                                      "text/plain": ["<Figure>"]}})
            plt.close("all")
            print(f"  cell {i:>3} ok   ({time.time() - t0:5.1f}s)", flush=True)
        except Exception:  # noqa: BLE001
            flush_stream()
            tb = traceback.format_exc()
            print(f"  cell {i:>3} FAILED\n{tb}", flush=True)
            outs.append({"output_type": "error", "ename": "Error", "evalue": "see traceback",
                         "traceback": tb.splitlines()})
            outputs_list.append(cell)
            raise
        outputs_list.append(cell)
    print(f"All cells executed in {time.time() - t_all:.0f}s", flush=True)
    return outputs_list


def main() -> None:
    import os

    NB_DIR.mkdir(exist_ok=True)
    os.chdir(NB_DIR)  # run like a notebook opened from notebooks/
    sys.path.insert(0, str(ROOT))
    cells = execute_cells()
    nb = {
        "cells": cells,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": sys.version.split()[0]},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    with open(NB_PATH, "w", encoding="utf-8") as f:
        json.dump(nb, f, indent=1)
    print("Notebook written to", NB_PATH)


if __name__ == "__main__":
    main()
