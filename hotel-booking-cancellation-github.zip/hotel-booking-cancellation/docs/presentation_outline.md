# Presentation outline (12 slides, about 15-20 minutes)

The finished deck is `docs/hotel_booking_cancellation.pptx` (rebuild it with `node scripts/build_deck.js`; numbers are read from `models/model_metadata.json`). Add a real screenshot on slide 11.

| # | Slide | Key message | Visual |
|---|---|---|---|
| 1 | Project introduction | Predict which hotel bookings will be canceled. Headline: test ROC-AUC 0.866. | Title + headline number |
| 2 | Problem statement | 119,390 raw bookings, 37.0 % canceled (27.7 % after de-duplication). Empty rooms cost revenue. | 3 stat cards |
| 3 | Business objectives | Understand, predict, quantify, act. | 4 cards |
| 4 | Dataset description | Kaggle Hotel Booking Demand; cleaning funnel 119,390 → 86,625 bookings. | Funnel cards |
| 5 | Exploratory data analysis | Lead time 8.5 % → 39.7 %; Online TA 35.5 % vs Direct 14.8 %; previous cancellation 68 %. | Two EDA charts |
| 6 | Data preprocessing | Clean → split first → engineer → impute/scale/encode → model. Leakage found (status columns, parking). | Pipeline flow |
| 7 | Machine-learning algorithms | Logistic Regression, Decision Tree, Random Forest, Gradient Boosting: how each works, pros and cons. | 4 cards |
| 8 | Model comparison | 5-fold CV: Random Forest best (ROC-AUC 0.865). Tuning gave no meaningful gain (0.8633 → 0.8636). | Bar chart + table |
| 9 | Model evaluation | Threshold 0.31: recall 0.755, precision 0.592, F1 0.664. Precision/recall trade-off. | Metric cards + confusion matrices |
| 10 | Feature importance | Market segment, country, lead time, special requests. Importance is not causation. | Permutation-importance chart |
| 11 | Web application demo | Home, Prediction, Analytics Dashboard; live demo of a booking. | Screenshot placeholder |
| 12 | Conclusion and future improvements | Honest results; add features (season, room type, payment), calibration, SHAP, cost-based threshold. | Two columns |

## Suggested talking points
- **Leakage story (slide 6):** `reservation_status` restates the answer; no booking with a parking space was ever canceled, and removing that field lowered ROC-AUC from 0.882 to 0.866. The lower number is the honest one.
- **Why recall and precision (slide 9):** a missed cancellation is an empty room; a false alarm can lead to overbooking and a relocated guest. The threshold lets a hotel choose its balance.
- **Deposit caveat (slide 10):** "Non Refund" bookings cancel 94.7 % of the time, but they are 1.2 % of bookings; this is an association, not proof that deposits cause cancellations.
