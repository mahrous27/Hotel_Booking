"""End-to-end training script.

Run from the project root:

    python -m src.train

Steps
-----
1. Load + clean the data, then split into train / test (before any fitting).
2. Compare a baseline and four algorithms with cross-validation (train only).
3. Pick the best algorithm using CV ROC-AUC (never the test set).
4. Tune it with RandomizedSearchCV (train only).
5. Choose a decision threshold from out-of-fold predictions (train only).
6. Evaluate ONCE on the untouched test set.
7. Explain the model (feature / permutation importance) and save everything.
"""
from __future__ import annotations

import json
import time
import warnings

import joblib
import matplotlib

matplotlib.use("Agg")  # no display needed
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.base import clone
from sklearn.metrics import classification_report, confusion_matrix, roc_curve
from sklearn.model_selection import (
    RandomizedSearchCV, StratifiedKFold, cross_val_predict, cross_validate,
)

from . import config as cfg
from . import plots
from .analysis import (
    aggregate_native_importance, dashboard_aggregates, error_analysis,
    parking_leakage_check, permutation_importance_raw,
)
from .data import load_and_split
from .modeling import (
    best_f1_threshold, get_models, get_param_distributions, metrics_at_threshold,
    threshold_table,
)

warnings.filterwarnings("ignore")


def banner(text: str) -> None:
    print("\n" + "=" * 78 + f"\n{text}\n" + "=" * 78, flush=True)


def save_fig(fig, name: str) -> None:
    cfg.FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(cfg.FIGURES_DIR / name, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    t0 = time.time()
    cfg.MODELS_DIR.mkdir(exist_ok=True)
    cfg.REPORTS_DIR.mkdir(exist_ok=True)

    # ------------------------------------------------------------------ 1
    banner("1. Load, clean and split the data")
    raw, clean, report, X_train, X_test, y_train, y_test = load_and_split()
    for k, v in report.items():
        print(f"  {k:<24}{v:,.4f}" if isinstance(v, float) else f"  {k:<24}{v:,}")
    print(f"  train: {X_train.shape}  test: {X_test.shape}")
    print(f"  cancel rate  train={y_train.mean():.4f}  test={y_test.mean():.4f}")
    print(f"  features used: {cfg.NUMERIC_FEATURES + cfg.CATEGORICAL_FEATURES}")

    banner("1b. Leakage check for required_car_parking_spaces")
    leak = parking_leakage_check(clean, X_train, X_test, y_train, y_test) if not cfg.USE_PARKING_FEATURE else {}
    for k, v in leak.items():
        print(f"  {k:<32}{v:,.4f}" if isinstance(v, float) else f"  {k:<32}{v:,}")

    # ------------------------------------------------------------------ 2
    banner("2. Compare baseline + 4 algorithms (5-fold CV on TRAIN only)")
    cv = StratifiedKFold(n_splits=cfg.CV_FOLDS_COMPARE, shuffle=True, random_state=cfg.RANDOM_STATE)
    scoring = {"roc_auc": "roc_auc", "pr_auc": "average_precision", "f1": "f1",
               "precision": "precision", "recall": "recall", "accuracy": "accuracy"}
    models = get_models()
    rows, test_proba = [], {}
    for name, pipe in models.items():
        t = time.time()
        res = cross_validate(pipe, X_train, y_train, cv=cv, scoring=scoring, n_jobs=1)
        row = {"model": name}
        for m in scoring:
            row[f"cv_{m}_mean"] = res[f"test_{m}"].mean()
            row[f"cv_{m}_std"] = res[f"test_{m}"].std()
        # fit on the full training set -> test-set numbers (for the comparison table only)
        fitted = clone(pipe).fit(X_train, y_train)
        p = fitted.predict_proba(X_test)[:, 1]
        test_proba[name] = p
        tm = metrics_at_threshold(y_test, p, 0.5)
        for m in ["accuracy", "precision", "recall", "f1", "roc_auc", "pr_auc"]:
            row[f"test_{m}"] = tm[m]
        row["fit_seconds"] = time.time() - t
        rows.append(row)
        print(f"  {name:<28} CV ROC-AUC={row['cv_roc_auc_mean']:.4f}  CV F1={row['cv_f1_mean']:.4f}"
              f"  ({row['fit_seconds']:.0f}s)", flush=True)
    comparison = pd.DataFrame(rows)
    comparison.to_csv(cfg.REPORTS_DIR / "model_comparison.csv", index=False)
    save_fig(plots.plot_model_comparison(comparison), "model_comparison_cv.png")

    # ------------------------------------------------------------------ 3
    banner("3. Select the best algorithm (by CV ROC-AUC, training data only)")
    candidates = comparison[~comparison["model"].str.startswith("Baseline")]
    best_name = candidates.sort_values("cv_roc_auc_mean", ascending=False).iloc[0]["model"]
    print(f"  Selected algorithm: {best_name}")

    # ------------------------------------------------------------------ 4
    banner(f"4. Hyper-parameter tuning: RandomizedSearchCV for {best_name}")
    base_pipe = models[best_name]
    search = RandomizedSearchCV(
        base_pipe,
        param_distributions=get_param_distributions(best_name),
        n_iter=cfg.N_ITER_SEARCH,
        scoring="roc_auc",
        cv=StratifiedKFold(cfg.CV_FOLDS_TUNING, shuffle=True, random_state=cfg.RANDOM_STATE),
        random_state=cfg.RANDOM_STATE,
        refit=True,
        n_jobs=1,
        verbose=1,
    )
    search.fit(X_train, y_train)

    # Fair check: score the UNTUNED model with exactly the same 3 folds. We keep
    # the tuned model only if it really is better.
    cv_tune = StratifiedKFold(cfg.CV_FOLDS_TUNING, shuffle=True, random_state=cfg.RANDOM_STATE)
    untuned_cv = cross_validate(clone(base_pipe), X_train, y_train, cv=cv_tune,
                                scoring="roc_auc", n_jobs=1)["test_score"].mean()
    tuned_better = bool(search.best_score_ > untuned_cv)
    print(f"  Untuned CV ROC-AUC (same 3 folds): {untuned_cv:.4f}")
    print(f"  Tuned   CV ROC-AUC (same 3 folds): {search.best_score_:.4f}")
    print(f"  -> {'keeping the TUNED model' if tuned_better else 'tuning did not help: keeping the UNTUNED model'}")
    best_pipe = search.best_estimator_ if tuned_better else clone(base_pipe).fit(X_train, y_train)
    best_params = {k.replace("model__", ""): (v.item() if hasattr(v, "item") else v)
                   for k, v in search.best_params_.items()}
    print(f"  Best params : {best_params}")
    print(f"  Best CV ROC-AUC (3-fold): {search.best_score_:.4f}")
    cv_results = pd.DataFrame(search.cv_results_)
    keep = [c for c in cv_results.columns if c.startswith("param_") or c in
            ("mean_test_score", "std_test_score", "rank_test_score", "mean_fit_time")]
    cv_results[keep].sort_values("rank_test_score").to_csv(
        cfg.REPORTS_DIR / "tuning_results.csv", index=False)

    # ------------------------------------------------------------------ 5
    banner("5. Threshold analysis (out-of-fold predictions on TRAIN)")
    oof = cross_val_predict(
        clone(best_pipe), X_train, y_train,
        cv=StratifiedKFold(5, shuffle=True, random_state=cfg.RANDOM_STATE),
        method="predict_proba", n_jobs=1,
    )[:, 1]
    thr_table = threshold_table(y_train, oof)
    thr_table.to_csv(cfg.REPORTS_DIR / "threshold_analysis.csv", index=False)
    chosen = best_f1_threshold(thr_table)
    row = thr_table[thr_table["threshold"] == chosen].iloc[0]
    print(f"  Threshold maximising F1 : {chosen:.2f}")
    print(f"  OOF precision={row['precision']:.3f}  recall={row['recall']:.3f}  F1={row['f1']:.3f}")
    save_fig(plots.plot_threshold_analysis(thr_table, chosen), "threshold_analysis.png")

    # ------------------------------------------------------------------ 6
    banner("6. Final evaluation on the untouched TEST set")
    proba = best_pipe.predict_proba(X_test)[:, 1]
    m_default = metrics_at_threshold(y_test, proba, 0.5)
    m_final = metrics_at_threshold(y_test, proba, chosen)
    for label, m in [("threshold 0.50 (default)", m_default), (f"threshold {chosen:.2f} (chosen)", m_final)]:
        print(f"  {label:<26} acc={m['accuracy']:.4f} prec={m['precision']:.4f} "
              f"rec={m['recall']:.4f} F1={m['f1']:.4f} ROC-AUC={m['roc_auc']:.4f}")
    y_pred = (proba >= chosen).astype(int)
    cls_report = classification_report(y_test, y_pred, target_names=["Not Canceled", "Canceled"], digits=4)
    print("\n" + cls_report)
    (cfg.REPORTS_DIR / "classification_report.txt").write_text(cls_report, encoding="utf-8")

    cm_default = confusion_matrix(y_test, (proba >= 0.5).astype(int))
    cm_final = confusion_matrix(y_test, y_pred)
    save_fig(plots.plot_confusion_matrices(
        {"Threshold = 0.50": cm_default, f"Chosen threshold = {chosen:.2f}": cm_final}),
        "confusion_matrices.png")
    roc_models = {n: p for n, p in test_proba.items() if not n.startswith("Baseline")}
    roc_models[f"Final {best_name}"] = proba
    save_fig(plots.plot_roc_curves(y_test, roc_models), "roc_curves.png")
    fpr, tpr, _ = roc_curve(y_test, proba)
    step = max(1, len(fpr) // 200)

    # ------------------------------------------------------------------ 7
    banner("7. Error analysis and feature importance")
    errors = error_analysis(X_test, y_test, proba, chosen)
    native = aggregate_native_importance(best_pipe)
    perm = permutation_importance_raw(best_pipe, X_test, y_test)
    print("  Top permutation importances (drop in ROC-AUC when shuffled):")
    print(perm.head(8).round(4).to_string(index=False))
    save_fig(plots.plot_importance(native, "importance", "Built-in feature importance (aggregated)"),
             "feature_importance.png")
    save_fig(plots.plot_importance(perm, "importance_mean", "Permutation importance (drop in ROC-AUC)",
                                   err_col="importance_std"), "permutation_importance.png")

    # ------------------------------------------------------------------ 8
    banner("8. Save model and metadata")
    joblib.dump(best_pipe, cfg.MODEL_PATH, compress=3)
    size_mb = cfg.MODEL_PATH.stat().st_size / 1e6
    print(f"  Saved {cfg.MODEL_PATH} ({size_mb:.1f} MB)")

    train_clean = clean.loc[:, cfg.RAW_CATEGORICAL]
    options = {c: sorted(train_clean[c].dropna().unique().tolist()) for c in cfg.RAW_CATEGORICAL}
    options["country"] = clean["country"].value_counts().index.tolist()  # most frequent first
    metadata = {
        "project": "Hotel Booking Cancellation Prediction",
        "best_algorithm": best_name,
        "best_params": best_params,
        "tuning_cv_roc_auc": float(search.best_score_),
        "untuned_cv_roc_auc": float(untuned_cv),
        "tuned_model_used": tuned_better,
        "parking_leakage_check": leak,
        "use_parking_feature": cfg.USE_PARKING_FEATURE,
        "threshold": chosen,
        "sklearn_version": sklearn.__version__,
        "random_state": cfg.RANDOM_STATE,
        "cleaning_report": report,
        "n_train": int(len(X_train)), "n_test": int(len(X_test)),
        "features_used": {"raw": cfg.RAW_FEATURES, "engineered": cfg.ENGINEERED_NUMERIC},
        "leakage_columns_removed": cfg.LEAKAGE_COLUMNS,
        "suspected_leakage_columns": cfg.SUSPECTED_LEAKAGE_COLUMNS,
        "model_comparison": comparison.round(5).to_dict("records"),
        "test_metrics_default_threshold": m_default,
        "test_metrics_final": m_final,
        "classification_report": cls_report,
        "roc_curve": {"fpr": fpr[::step].round(4).tolist(), "tpr": tpr[::step].round(4).tolist()},
        "threshold_table": thr_table.round(4).to_dict("records"),
        "permutation_importance": perm.round(5).to_dict("records"),
        "native_importance": native.round(5).to_dict("records"),
        "error_analysis": errors,
        "category_options": options,
        "numeric_ranges": {c: [float(clean[c].min()), float(clean[c].max()),
                               float(clean[c].median())] for c in ["lead_time", "adr"]},
        "dashboard": dashboard_aggregates(raw, clean),
        "training_seconds": round(time.time() - t0, 1),
    }
    with open(cfg.METADATA_PATH, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    print(f"  Saved {cfg.METADATA_PATH}")
    print(f"\nDone in {time.time() - t0:.0f} s.")


if __name__ == "__main__":
    main()
