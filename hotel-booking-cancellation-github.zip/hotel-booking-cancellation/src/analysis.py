"""Reusable analysis helpers: binning, group summaries, error analysis, importances."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance

from . import config as cfg

LEAD_BINS = [-1, 7, 30, 90, 180, 365, np.inf]
LEAD_LABELS = ["0-7 d", "8-30 d", "31-90 d", "91-180 d", "181-365 d", "366+ d"]
ADR_BINS = [-0.01, 50, 75, 100, 125, 150, np.inf]
ADR_LABELS = ["<=50", "50-75", "75-100", "100-125", "125-150", ">150"]


def lead_time_bin(s: pd.Series) -> pd.Series:
    return pd.cut(s, bins=LEAD_BINS, labels=LEAD_LABELS).astype(str)


def adr_bin(s: pd.Series) -> pd.Series:
    return pd.cut(s, bins=ADR_BINS, labels=ADR_LABELS).astype(str)


def cancel_rate_by(df: pd.DataFrame, col: str, order: list | None = None,
                   min_count: int = 1) -> pd.DataFrame:
    """Booking count and cancellation rate for each value of `col`."""
    g = (df.groupby(col)[cfg.TARGET].agg(bookings="size", cancellations="sum")
         .reset_index())
    g["cancel_rate"] = g["cancellations"] / g["bookings"]
    g = g[g["bookings"] >= min_count]
    if order is not None:
        g[col] = pd.Categorical(g[col], categories=order, ordered=True)
        g = g.sort_values(col)
    else:
        g = g.sort_values("cancel_rate", ascending=False)
    g[col] = g[col].astype(str)
    return g.reset_index(drop=True)


def dashboard_aggregates(raw: pd.DataFrame, clean: pd.DataFrame) -> dict:
    """Small summary tables stored in the metadata file for the app dashboard."""
    d = clean.copy()
    d["lead_time_group"] = lead_time_bin(d["lead_time"])
    d["adr_group"] = adr_bin(d["adr"])
    d["prev_cancel_group"] = np.where(d["previous_cancellations"] > 0,
                                      "Has previous cancellation", "No previous cancellation")
    out = {
        "total_bookings_raw": int(len(raw)),
        "cancel_rate_raw": float(raw[cfg.TARGET].mean()),
        "total_bookings_clean": int(len(d)),
        "cancel_rate_clean": float(d[cfg.TARGET].mean()),
        "canceled_clean": int(d[cfg.TARGET].sum()),
        "not_canceled_clean": int((d[cfg.TARGET] == 0).sum()),
        "by_hotel": cancel_rate_by(d, "hotel").to_dict("records"),
        "by_deposit_type": cancel_rate_by(d, "deposit_type").to_dict("records"),
        "by_market_segment": cancel_rate_by(d, "market_segment").to_dict("records"),
        "by_customer_type": cancel_rate_by(d, "customer_type").to_dict("records"),
        "by_distribution_channel": cancel_rate_by(d, "distribution_channel", min_count=50).to_dict("records"),
        "by_lead_time": cancel_rate_by(d, "lead_time_group", LEAD_LABELS).to_dict("records"),
        "by_adr": cancel_rate_by(d, "adr_group", ADR_LABELS).to_dict("records"),
        "by_previous_cancellation": cancel_rate_by(d, "prev_cancel_group").to_dict("records"),
        "by_country_top10": cancel_rate_by(
            d[d["country"].isin(d["country"].value_counts().head(10).index)], "country"
        ).to_dict("records"),
    }
    return out


def error_analysis(X_test: pd.DataFrame, y_test, proba, threshold: float) -> dict:
    """Where does the model make mistakes? Error rates per business segment."""
    d = X_test.copy()
    d["actual"] = np.asarray(y_test)
    d["pred"] = (np.asarray(proba) >= threshold).astype(int)
    d["is_error"] = (d["actual"] != d["pred"]).astype(int)
    d["false_negative"] = ((d["actual"] == 1) & (d["pred"] == 0)).astype(int)
    d["false_positive"] = ((d["actual"] == 0) & (d["pred"] == 1)).astype(int)
    d["lead_time_group"] = lead_time_bin(d["lead_time"])

    result = {}
    for col in ["deposit_type", "market_segment", "hotel", "customer_type", "lead_time_group"]:
        g = d.groupby(col).agg(
            bookings=("actual", "size"),
            actual_cancel_rate=("actual", "mean"),
            error_rate=("is_error", "mean"),
            false_negatives=("false_negative", "sum"),
            false_positives=("false_positive", "sum"),
            actual_cancels=("actual", "sum"),
        ).reset_index()
        g["missed_cancel_share"] = g["false_negatives"] / g["actual_cancels"].replace(0, np.nan)
        g = g[g["bookings"] >= 30].sort_values("error_rate", ascending=False)
        result[col] = g.round(4).to_dict("records")
    return result


def aggregate_native_importance(pipeline) -> pd.DataFrame:
    """Model-built-in importance, with one-hot columns summed back per feature."""
    pre = pipeline.named_steps["preprocess"]
    model = pipeline.named_steps["model"]
    names = pre.get_feature_names_out()
    if hasattr(model, "feature_importances_"):
        values = model.feature_importances_
    elif hasattr(model, "coef_"):
        values = np.abs(model.coef_[0])
    else:
        return pd.DataFrame(columns=["feature", "importance"])
    imp = pd.Series(values, index=names)
    rows = {}
    for name, val in imp.items():
        base = name
        if name.startswith("num__"):
            base = name[len("num__"):]
        elif name.startswith("cat__"):
            rest = name[len("cat__"):]
            base = next((c for c in cfg.CATEGORICAL_FEATURES if rest.startswith(c + "_")), rest)
        rows[base] = rows.get(base, 0.0) + float(val)
    out = pd.DataFrame({"feature": list(rows), "importance": list(rows.values())})
    out["importance"] = out["importance"] / out["importance"].sum()
    return out.sort_values("importance", ascending=False).reset_index(drop=True)


def permutation_importance_raw(pipeline, X, y, n_repeats=5, sample=10000, seed=cfg.RANDOM_STATE):
    """Permutation importance on the RAW input columns (easy to explain).

    Each raw column is shuffled and the drop in ROC-AUC is recorded - the bigger
    the drop, the more the model relies on that column.
    """
    if len(X) > sample:
        idx = X.sample(sample, random_state=seed).index
        Xs, ys = X.loc[idx], y.loc[idx]
    else:
        Xs, ys = X, y
    r = permutation_importance(pipeline, Xs, ys, scoring="roc_auc",
                               n_repeats=n_repeats, random_state=seed, n_jobs=1)
    out = pd.DataFrame({"feature": Xs.columns, "importance_mean": r.importances_mean,
                        "importance_std": r.importances_std})
    return out.sort_values("importance_mean", ascending=False).reset_index(drop=True)


def parking_leakage_check(clean: pd.DataFrame, X_train, X_test, y_train, y_test) -> dict:
    """Quantify the suspected leakage of `required_car_parking_spaces`.

    1. Count cancellations among bookings that have a parking space.
    2. Fit the same simple Random Forest with and without that column and
       compare the test ROC-AUC (same split, same simple preprocessing).
    """
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import roc_auc_score
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder

    col = "required_car_parking_spaces"
    has = clean[col] > 0
    out = {
        "bookings_with_parking": int(has.sum()),
        "cancellations_among_them": int(clean.loc[has, cfg.TARGET].sum()),
        "cancel_rate_without_parking": float(clean.loc[~has, cfg.TARGET].mean()),
    }
    base_num = [c for c in cfg.RAW_NUMERIC if c != col]
    cats = cfg.RAW_CATEGORICAL

    def fit_auc(use_parking: bool) -> float:
        num = base_num + ([col] if use_parking else [])
        def prep(X):
            Z = X[base_num + cats].copy()
            Z["children"] = Z["children"].fillna(0)
            if use_parking:
                Z[col] = clean.loc[X.index, col].values
            return Z[num + cats]
        pipe = Pipeline([
            ("pre", ColumnTransformer([("c", OneHotEncoder(handle_unknown="infrequent_if_exist",
                                                          min_frequency=100, sparse_output=False), cats)],
                                      remainder="passthrough")),
            ("rf", RandomForestClassifier(n_estimators=100, min_samples_leaf=3, max_features="sqrt",
                                          n_jobs=-1, random_state=cfg.RANDOM_STATE)),
        ])
        pipe.fit(prep(X_train), y_train)
        return float(roc_auc_score(y_test, pipe.predict_proba(prep(X_test))[:, 1]))

    out["test_roc_auc_with_parking"] = fit_auc(True)
    out["test_roc_auc_without_parking"] = fit_auc(False)
    return out
