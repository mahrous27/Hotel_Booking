"""Basic tests: run with `python -m pytest tests` or `python tests/test_predict.py`."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.predict import (load_metadata, load_model, predict_booking, recommendation,
                         risk_level, validate_booking)

BOOKING = {
    "hotel": "City Hotel", "lead_time": 120, "adults": 2, "children": 0,
    "stays_in_weekend_nights": 1, "stays_in_week_nights": 2, "meal": "BB",
    "country": "PRT", "market_segment": "Online TA", "distribution_channel": "TA/TO",
    "is_repeated_guest": 0, "previous_cancellations": 0, "deposit_type": "No Deposit",
    "customer_type": "Transient", "adr": 110.0,
    "total_of_special_requests": 0,
}


def test_valid_booking_gives_probability():
    model, meta = load_model(), load_metadata()
    pred = predict_booking(model, BOOKING, meta["threshold"])
    assert 0.0 <= pred.probability <= 1.0
    assert pred.risk_level in {"Low", "Medium", "High"}
    assert len(recommendation(pred, BOOKING)) >= 1


def test_unseen_country_and_missing_children_do_not_crash():
    model, meta = load_model(), load_metadata()
    b = dict(BOOKING, country="ZZZ")
    assert 0 <= predict_booking(model, b, meta["threshold"]).probability <= 1


def test_invalid_inputs_are_rejected():
    assert validate_booking(dict(BOOKING, adults=0, children=0))
    assert validate_booking(dict(BOOKING, stays_in_weekend_nights=0, stays_in_week_nights=0))
    assert validate_booking(dict(BOOKING, adr=-5))
    assert validate_booking({k: v for k, v in BOOKING.items() if k != "hotel"})
    assert validate_booking(dict(BOOKING, lead_time="abc"))


def test_risk_bands():
    assert risk_level(0.9, 0.32) == "High"
    assert risk_level(0.25, 0.32) == "Medium"
    assert risk_level(0.05, 0.32) == "Low"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("PASS", name)
