# 🏨 Hotel Booking Cancellation Prediction

An end-to-end machine-learning project that predicts whether a hotel booking will be **canceled**, estimates the **cancellation probability**, and turns the results into practical advice for hotel managers. It includes a reproducible training pipeline, an analysis notebook, and a three-page **Streamlit** web app.

> **Headline result (untouched test set, 17,325 bookings):** tuned Random Forest, ROC-AUC **0.866**, recall **0.755** and precision **0.592** for canceled bookings at a decision threshold of 0.31 (chosen on training data only).

---

## 1. Problem statement
Cancellations leave rooms empty and cost hotels revenue. If a hotel knew which bookings are likely to be canceled, it could send reminders, adjust deposit policies and plan overbooking more safely. The task: given the information available when a booking is made, predict `is_canceled` (1 = canceled, 0 = not canceled).

## 2. Business objectives
- Analyse historical bookings and find the factors that influence cancellations.
- Predict whether a new booking will be canceled, and with what probability.
- Flag high-risk bookings and support decisions on deposits, reminders and overbooking.

## 3. Dataset
**Hotel Booking Demand** (Kaggle): <https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand>
Real bookings for a city hotel and a resort hotel in Portugal. 119,390 rows, 32 columns; target `is_canceled`.

The raw CSV is **not committed** (see `.gitignore`). To get it:
1. Download it from the Kaggle link above (free account needed) and unzip `archive.zip`.
2. Place `hotel_bookings.csv` in the `data/` folder: `data/hotel_bookings.csv`.

## 4. Technologies
Python 3.12 · pandas · NumPy · scikit-learn (Pipeline, ColumnTransformer, RandomizedSearchCV) · Matplotlib · Seaborn · Joblib · Streamlit (Altair charts)

## 5. Project structure
```
hotel-booking-cancellation/
├── data/hotel_bookings.csv        # download from Kaggle (not committed)
├── notebooks/hotel_booking_analysis.ipynb   # full analysis, with outputs
├── models/
│   ├── best_model.joblib          # saved scikit-learn pipeline (features + preprocessing + model)
│   └── model_metadata.json        # threshold, metrics, importances, dashboard statistics
├── src/                           # code shared by the notebook, training script and app
│   ├── config.py  data.py  features.py  modeling.py  analysis.py  plots.py  predict.py  train.py
├── scripts/build_notebook.py      # rebuilds the notebook and stores real outputs in it
├── reports/                       # figures, model_comparison.csv, tuning/threshold tables, logs
├── tests/                         # inference tests + app smoke test
├── docs/presentation_outline.md   # 12-slide outline (a .pptx version is in docs/ too)
├── app.py                         # Streamlit application
├── requirements.txt
└── README.md
```

## 6. Methodology
1. **Cleaning (before the split):** removed 31,994 exact duplicates, 166 bookings with no adult/child, 591 with zero nights, 2 invalid prices and 12 absurd party sizes → **86,625 bookings, 27.7 % canceled.** Duplicates are removed *before* splitting so the same booking cannot appear in both train and test.
2. **Split first:** stratified 80/20 train/test split **before** fitting any transformer.
3. **Leakage control:** `reservation_status` and `reservation_status_date` reveal the outcome and are removed. `required_car_parking_spaces` is excluded too (see below). Fields only known late (`assigned_room_type`, `booking_changes`, …) are not used.
4. **Pipeline:** feature engineering (`total_nights`, `total_guests`, `adr_per_person`, `weekend_share`, flags) → imputation → scaling (Logistic Regression only) → one-hot encoding (rare countries grouped, unseen values handled) → model. All fitted on training data only.
5. **Model selection:** baseline + Logistic Regression, Decision Tree, Random Forest, Gradient Boosting compared with **5-fold cross-validation on the training set**; chosen by ROC-AUC (not accuracy).
6. **Tuning:** `RandomizedSearchCV` (8 candidates × 3 folds, ROC-AUC) on training data only.
7. **Threshold:** chosen from out-of-fold training predictions (best F1 → 0.31).
8. **Evaluation:** once, on the untouched test set; error analysis and permutation importance.

### ⚠️ A data-leakage finding: parking
All **7,290** cleaned bookings with a parking space were *not* canceled (vs. 30.2 % for the rest). That is not realistic behaviour; the field is evidently recorded only after a guest stays. Using it lifted the test ROC-AUC from **0.866 to 0.882** in a same-model comparison, so it was inflating the results. It is therefore **excluded** from the model and from the prediction form. (Your original brief listed parking as a form field; to bring it back anyway, set `USE_PARKING_FEATURE = True` in `src/config.py` and retrain, but expect over-optimistic scores.)

## 7. EDA findings (cleaned data; all numbers computed from the data)
| Factor | Finding |
|---|---|
| Lead time | Cancellation rate rises from **8.5 %** (0-7 days ahead) to **39.7 %** (181-365 days). |
| Previous cancellations | **68.2 %** cancel again vs **26.9 %** for guests with no previous cancellation. |
| Market segment | Online TA **35.5 %**, Groups 27.2 %, Offline TA/TO 14.9 %, Direct 14.8 %, Corporate 12.2 %. |
| Hotel | City Hotel **30.2 %** vs Resort Hotel **23.7 %**. |
| Customer type | Transient 30.3 % · Contract 16.4 % · Transient-Party 15.3 % · Group 7.8 %. |
| ADR | Rate rises with price: 15.6 % (≤ 50) → 35.1 % (> 150). |
| Special requests | 33.5 % cancel with none vs 22.5 % with one and 10.6 % with four. |
| Deposit type | "Non Refund" bookings cancel **94.7 %** of the time but are only 1.2 % of bookings; this is an association within a small special group, **not** proof that deposits cause cancellations. |

Figures: `reports/figures/eda_*.png` (created by the notebook).

## 8. Model comparison (5-fold CV on the training set)
| Model | ROC-AUC | F1 | Precision | Recall | Accuracy |
|---|---|---|---|---|---|
| Baseline (majority class) | 0.500 | 0.000 | 0.000 | 0.000 | 0.723 |
| Logistic Regression | 0.809 | 0.523 | 0.681 | 0.425 | 0.786 |
| Decision Tree (depth 8) | 0.835 | 0.593 | 0.656 | 0.541 | 0.795 |
| **Random Forest** | **0.865** | **0.614** | 0.725 | 0.532 | 0.815 |
| Gradient Boosting | 0.852 | 0.587 | 0.702 | 0.504 | 0.804 |

(Metrics at the default 0.5 threshold.) The Random Forest wins because cancellation depends on *combinations* of factors (channel × lead time × country × requests) that a linear model cannot capture and a single tree captures unstably. Tuning (`n_estimators=200, max_depth=18, min_samples_leaf=5, max_features=0.3`) improved 3-fold CV ROC-AUC only from 0.8633 to 0.8636, which is within noise: **tuning gave no meaningful gain**, so better features are the more promising next step.

![Model comparison](reports/figures/model_comparison_cv.png)

## 9. Final evaluation (test set, threshold 0.31)
| Metric | Threshold 0.50 | **Threshold 0.31 (chosen)** |
|---|---|---|
| Accuracy | 0.814 | 0.789 |
| Precision (canceled) | 0.708 | 0.592 |
| Recall (canceled) | 0.559 | **0.755** |
| F1 (canceled) | 0.625 | 0.664 |
| ROC-AUC | 0.866 | 0.866 |
| PR-AUC | 0.726 | 0.726 |

Confusion matrix at 0.31: 10,039 true negatives · 2,491 false positives · 1,174 false negatives · 3,621 true positives.

- **Recall** = share of real cancellations caught (missed ones = empty rooms and lost revenue).
- **Precision** = share of warnings that are right (false alarms = needless reminders or risky overbooking).
- Lowering the threshold from 0.50 to 0.31 raises recall from 56 % to 76 % at the cost of precision (71 % → 59 %). Hotels that fear relocating guests more than empty rooms should raise the threshold; the notebook (Section 7) shows how the best threshold moves under different cost assumptions (illustrative, not real costs).

![Confusion matrices](reports/figures/confusion_matrices.png)
![ROC curves](reports/figures/roc_curves.png)

**Error analysis.** The model's mistakes concentrate in *Online TA* bookings (about three quarters of all errors, since it is the largest and most mixed segment) and in mid lead times (8-180 days, error rate ≈ 22-26 %). Last-minute bookings (0-7 days) rarely cancel (≈ 9 %), and the model misses about 80 % of those few. Small segments (Complementary, Aviation) are too small for firm conclusions.

## 10. Feature importance
Permutation importance (drop in ROC-AUC when a column is shuffled, test set): **market segment (0.126), country (0.106), lead time (0.097)**, then special requests (0.064), ADR (0.039), customer type (0.039) and previous cancellations (0.013). *Importance shows what the model uses, not what causes cancellations.*

![Permutation importance](reports/figures/permutation_importance.png)

### Recommendations for hotel management
1. **Flag high-risk bookings** (probability ≥ 0.31), especially online-agency bookings made months ahead with no special requests.
2. **Reconfirm early:** send reminders 2-4 weeks before arrival for long-lead, high-risk bookings so rooms can be resold.
3. **Test, don't assume, deposit policies:** pilot partial deposits or shorter free-cancellation windows on the riskiest channels and measure the effect (A/B test).
4. **Overbook with probabilities:** expected cancellations for a night = sum of booking probabilities; overbook by a fraction of that, with a safety margin.
5. **Encourage commitment:** invite guests to personalise their stay and push direct bookings.
6. **Retrain regularly** and monitor precision/recall.

## 11. How to run the project
```bash
# 1. create an environment (Python 3.12 recommended) and install
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. put hotel_bookings.csv into data/   (see section 3)

# 3. train: compare models, tune, choose threshold, evaluate, save models/ and reports/
python -m src.train                  # about 10 minutes on a single CPU core

# 4. (optional) rebuild the notebook with fresh outputs, or open it in Jupyter
python scripts/build_notebook.py     # or: pip install jupyter && jupyter notebook notebooks/

# 5. tests
python tests/test_predict.py
python tests/smoke_app.py            # runs the app logic without a browser

# 6. launch the web app
streamlit run app.py
```
The committed `models/` files let the app run without retraining. If your installed scikit-learn version differs from `requirements.txt` and loading the model fails, simply run step 3 again.

## 12. Web application
| Page | What it shows |
|---|---|
| **Home** | Title, description, objectives, dataset information |
| **Prediction** | Booking form → *Canceled / Not Canceled*, cancellation probability, colour risk bar with the threshold marked, and a practical recommendation. Inputs are validated (e.g. at least one guest and one night). |
| **Analytics Dashboard** | Total bookings, cancellation %, distribution chart, interactive cancellation-rate explorer, permutation importance, model metrics, ROC curve, confusion matrix, threshold analysis, model comparison |

*Screenshots (add yours after running the app):*
`docs/screenshots/home.png` · `docs/screenshots/prediction.png` · `docs/screenshots/dashboard.png`

The app loads `models/best_model.joblib`, which contains the **whole pipeline** (feature engineering + preprocessing + model), so the form data is transformed exactly as the training data was.

## 13. Deployment on Streamlit Community Cloud
1. Create a GitHub repository and push this folder. Commit `models/best_model.joblib` (≈ 18 MB, under GitHub's 100 MB limit) and `models/model_metadata.json`; the raw CSV is git-ignored and **not needed** by the app (dashboard statistics are stored in the metadata file).
2. Go to <https://share.streamlit.io>, sign in with GitHub and click **New app**.
3. Choose the repository and branch, set **Main file path** to `app.py`, and (under *Advanced settings*) pick Python 3.12.
4. Click **Deploy**. Streamlit Cloud installs `requirements.txt` automatically.
5. If the cloud environment cannot install an exact pinned version, loosen the pins in `requirements.txt` and re-run `python -m src.train` locally before committing the new model.

## 14. Limitations and future work
- Data from two Portuguese hotels (2015-2017); results may not transfer elsewhere.
- Only form-style booking information is used; arrival date/season, room type and payment details could raise performance. Tuning added almost nothing, so features, not algorithms, are the limit.
- Try a time-based split, probability calibration, XGBoost/LightGBM, SHAP explanations in the app, and real revenue/relocation costs to choose the threshold.
- Importance and insights show association, not causation.

## 15. Notes on verification
All metrics above come from running `python -m src.train` on the provided dataset (see `reports/training_log.txt` and `models/model_metadata.json`). The Streamlit app was smoke-tested with stand-in modules (`tests/smoke_app.py`) in an environment without Streamlit, so the visual layout should be checked once by running `streamlit run app.py`.
