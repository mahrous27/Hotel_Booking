"""Smoke test for app.py WITHOUT streamlit installed.

Streamlit and Altair are replaced by small stand-ins that record the calls the
app makes. This only checks that the app logic runs end-to-end with the saved
model and metadata (no exceptions); it does not check the visual layout. Run
the real app with `streamlit run app.py` to see it in a browser.
"""
import importlib
import sys
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def make_fake_streamlit(page: str, submit: bool = True):
    st = MagicMock(name="streamlit")
    st.calls = []
    ident = lambda *a, **k: (lambda f: f)
    st.cache_resource = ident
    st.cache_data = ident
    st.set_page_config = lambda **k: None
    st.sidebar.radio.return_value = page
    def new_col():
        col = MagicMock()
        col.metric.side_effect = lambda label, value, **k: st.calls.append((label, value))
        return col

    st.columns.side_effect = lambda n, **k: [new_col() for _ in range(n if isinstance(n, int) else len(n))]
    st.tabs.side_effect = lambda names: [new_col() for _ in names]
    st.selectbox.side_effect = lambda label, options, **k: list(options)[k.get("index", 0)]
    st.number_input.side_effect = lambda label, **k: k["value"]
    st.form_submit_button.return_value = submit
    st.metric.side_effect = lambda label, value, **k: st.calls.append((label, value))
    st.stop.side_effect = RuntimeError("st.stop called")
    return st


def run(page: str):
    st = make_fake_streamlit(page)
    sys.modules["streamlit"] = st
    sys.modules["altair"] = MagicMock(name="altair")
    sys.modules.pop("app", None)
    app = importlib.import_module("app")
    app.main()
    return st


if __name__ == "__main__":
    for page in ["Home", "Prediction", "Analytics Dashboard"]:
        st = run(page)
        print(f"OK  {page:<22} metrics shown: {st.calls[:8]}")
