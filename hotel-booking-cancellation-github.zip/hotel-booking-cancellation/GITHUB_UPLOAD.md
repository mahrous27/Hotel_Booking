# Publish this project on GitHub

## 1. Create the repository

1. Sign in at https://github.com/new.
2. Set the repository name to `hotel-booking-cancellation`.
3. Choose **Public** or **Private**.
4. Do not initialize it with a README, `.gitignore`, or license (this folder already contains project files).
5. Create the repository.

## 2. Upload from your computer

Extract `hotel-booking-cancellation-github.zip`, open a terminal in the extracted folder, then run:

```bash
git init
git add .
git status --short
git commit -m "Initial commit: hotel booking cancellation prediction"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/hotel-booking-cancellation.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to sign in, complete the browser/device authentication. GitHub no longer accepts account passwords for HTTPS Git operations; use the browser sign-in flow or a personal access token when prompted.

## 3. Deploy the app (optional)

1. Open https://share.streamlit.io/ and sign in with GitHub.
2. Select **New app**, then choose this repository and the `main` branch.
3. Set **Main file path** to `app.py`.
4. Deploy.

## Important notes

- `data/hotel_bookings.csv` is intentionally excluded. Download the Hotel Booking Demand dataset from https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand and put `hotel_bookings.csv` in `data/` only if you want to retrain the model.
- The trained model is included in `models/best_model.joblib` so the Streamlit app can load without the raw CSV.
- Check `git status --short` before committing. The raw dataset and local environment files should not appear in the staged changes.
