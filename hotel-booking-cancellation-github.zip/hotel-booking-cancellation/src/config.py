"""Central configuration: paths, random seed and feature lists.

Keeping everything in one place means the training script, the notebook and
the Streamlit app can never disagree about which columns the model uses.
"""
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "data" / "hotel_bookings.csv"
MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
MODEL_PATH = MODELS_DIR / "best_model.joblib"
METADATA_PATH = MODELS_DIR / "model_metadata.json"

# --------------------------------------------------------------------------
# Experiment settings
# --------------------------------------------------------------------------
TARGET = "is_canceled"
RANDOM_STATE = 42
TEST_SIZE = 0.20          # 20 % of the (de-duplicated) bookings are held out
CV_FOLDS_COMPARE = 5      # folds used to compare the four algorithms
CV_FOLDS_TUNING = 3       # folds used inside RandomizedSearchCV
N_ITER_SEARCH = 8         # random hyper-parameter combinations to try

# --------------------------------------------------------------------------
# Columns that must NEVER be used as features (data leakage)
# --------------------------------------------------------------------------
# `reservation_status` ("Canceled", "Check-Out", "No-Show") is the outcome of
# the booking, i.e. a re-statement of the target. `reservation_status_date`
# is the date on which that outcome happened.
LEAKAGE_COLUMNS = ["reservation_status", "reservation_status_date"]

# SUSPECTED LEAKAGE (found during EDA): `required_car_parking_spaces`.
# In the cleaned data every one of the ~7,300 bookings with a parking space
# was NOT canceled (0 cancellations) - a pattern that is not plausible as real
# guest behaviour. It suggests the field is only filled in once a guest has
# actually stayed, i.e. it is recorded AFTER the outcome. A model that uses it
# looks better than it will be on genuinely new bookings (test ROC-AUC drops
# from about 0.882 to 0.866 without it). So it is excluded by default.
# Set USE_PARKING_FEATURE = True and re-run `python -m src.train` to include it.
SUSPECTED_LEAKAGE_COLUMNS = ["required_car_parking_spaces"]
USE_PARKING_FEATURE = False

# Columns that are available in the dataset but deliberately NOT used:
#  - assigned_room_type, booking_changes, days_in_waiting_list: these are only
#    fully known late in the booking life-cycle (close to check-in or after a
#    cancellation), so they would not be available when scoring a new booking.
#  - agent, company: anonymised ID codes (company is ~94 % missing).
#  - arrival_date_*: kept out so the prediction form stays simple; listed as a
#    future improvement in the README.
EXCLUDED_COLUMNS = [
    "assigned_room_type", "booking_changes", "days_in_waiting_list",
    "agent", "company", "reserved_room_type", "babies",
    "arrival_date_year", "arrival_date_month", "arrival_date_week_number",
    "arrival_date_day_of_month", "previous_bookings_not_canceled",
]

# --------------------------------------------------------------------------
# Raw model inputs = exactly the fields of the Streamlit prediction form
# --------------------------------------------------------------------------
RAW_NUMERIC = [
    "lead_time", "adults", "children", "stays_in_weekend_nights",
    "stays_in_week_nights", "is_repeated_guest", "previous_cancellations",
    "adr", "total_of_special_requests",
] + (["required_car_parking_spaces"] if USE_PARKING_FEATURE else [])
RAW_CATEGORICAL = [
    "hotel", "meal", "country", "market_segment", "distribution_channel",
    "deposit_type", "customer_type",
]
RAW_FEATURES = RAW_NUMERIC + RAW_CATEGORICAL

# Features created by src.features.add_features()
ENGINEERED_NUMERIC = [
    "total_nights", "total_guests", "has_children", "adr_per_person",
    "weekend_share", "has_previous_cancellation", "has_special_requests",
] + (["has_parking"] if USE_PARKING_FEATURE else [])

# Features that reach the ColumnTransformer
NUMERIC_FEATURES = RAW_NUMERIC + ENGINEERED_NUMERIC
CATEGORICAL_FEATURES = RAW_CATEGORICAL

# Fixed, domain-based caps (not learned from data, so no leakage) used to
# tame extreme outliers such as a single booking with ADR = 5400.
OUTLIER_CAPS = {
    "lead_time": 500,
    "adr": 500.0,
    "adults": 6,
    "children": 6,
    "stays_in_weekend_nights": 10,
    "stays_in_week_nights": 21,
    "previous_cancellations": 10,
    "required_car_parking_spaces": 4,   # only applied if the column is used
}

DOWNLOAD_HELP = (
    "Dataset not found at: {path}\n\n"
    "How to get it:\n"
    "  1. Open https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand\n"
    "  2. Click 'Download' (a free Kaggle account is required) and unzip archive.zip\n"
    "  3. Copy 'hotel_bookings.csv' into the 'data/' folder of this project.\n"
)
