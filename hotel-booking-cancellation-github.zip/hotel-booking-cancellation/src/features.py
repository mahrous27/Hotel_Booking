"""Feature engineering and the scikit-learn preprocessing pipeline.

`add_features` is a plain function wrapped in a `FunctionTransformer`, so it
becomes the first step of the saved pipeline. That is what guarantees that the
Streamlit app transforms a new booking in exactly the same way as the
training data.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from . import config as cfg


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Clean raw inputs, cap outliers and create new features.

    Everything here is stateless (nothing is "learned" from the data), which
    is why it is safe to apply to both training and unseen bookings.
    """
    X = df[cfg.RAW_FEATURES].copy()

    # --- simple, rule-based cleaning -------------------------------------
    X["children"] = X["children"].fillna(0)
    X["country"] = X["country"].fillna("Unknown")
    # "Undefined" meal means "no meal package" -> same as SC in the data docs
    X["meal"] = X["meal"].replace("Undefined", "SC")

    # --- fixed outlier caps (domain knowledge, not data-driven) ----------
    for col, cap in cfg.OUTLIER_CAPS.items():
        if col in X.columns:
            X[col] = X[col].clip(lower=0, upper=cap)

    # --- engineered features ---------------------------------------------
    X["total_nights"] = X["stays_in_weekend_nights"] + X["stays_in_week_nights"]
    X["total_guests"] = X["adults"] + X["children"]
    X["has_children"] = (X["children"] > 0).astype(int)
    X["adr_per_person"] = X["adr"] / X["total_guests"].replace(0, np.nan)
    X["weekend_share"] = (
        X["stays_in_weekend_nights"] / X["total_nights"].replace(0, np.nan)
    )
    X["has_previous_cancellation"] = (X["previous_cancellations"] > 0).astype(int)
    X["has_special_requests"] = (X["total_of_special_requests"] > 0).astype(int)
    if cfg.USE_PARKING_FEATURE:
        X["has_parking"] = (X["required_car_parking_spaces"] > 0).astype(int)

    return X[cfg.NUMERIC_FEATURES + cfg.CATEGORICAL_FEATURES]


def build_preprocessor(scale_numeric: bool) -> ColumnTransformer:
    """ColumnTransformer: impute + (optionally) scale numbers, one-hot categories.

    scale_numeric=True  -> for Logistic Regression (sensitive to feature scale)
    scale_numeric=False -> for tree models (scale does not matter for them)
    """
    num_steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale_numeric:
        num_steps.append(("scaler", StandardScaler()))

    cat_steps = [
        ("imputer", SimpleImputer(strategy="constant", fill_value="Unknown")),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="infrequent_if_exist",  # unseen / rare -> "infrequent"
                min_frequency=100,                      # rare countries are grouped
                sparse_output=False,
            ),
        ),
    ]
    return ColumnTransformer(
        transformers=[
            ("num", Pipeline(num_steps), cfg.NUMERIC_FEATURES),
            ("cat", Pipeline(cat_steps), cfg.CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )


def make_pipeline(model, scale_numeric: bool = False) -> Pipeline:
    """Full pipeline: raw booking -> engineered features -> preprocessing -> model."""
    return Pipeline(
        steps=[
            ("features", FunctionTransformer(add_features, validate=False)),
            ("preprocess", build_preprocessor(scale_numeric)),
            ("model", model),
        ]
    )
