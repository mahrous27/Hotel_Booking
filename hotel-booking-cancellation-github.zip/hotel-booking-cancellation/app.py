"""Streamlit app: Hotel Booking Cancellation Prediction.

Run locally from the project root:

    streamlit run app.py

Pages
-----
* Home                 - project description, objectives, dataset information
* Prediction           - booking form -> prediction, probability, risk, advice
* Analytics Dashboard  - dataset statistics, important factors, model metrics

The app loads the saved pipeline (models/best_model.joblib) and the metadata
written by `python -m src.train`. Because the saved pipeline contains the
feature engineering and preprocessing steps, the form data goes through
exactly the same transformations as the training data.
"""
from __future__ import annotations

import altair as alt
import pandas as pd
import streamlit as st

from src import config as cfg
from src.predict import (
    build_input_frame, load_metadata, load_model, predict_booking,
    recommendation, validate_booking,
)

st.set_page_config(page_title="Hotel Booking Cancellation Prediction",
                   page_icon="🏨", layout="wide")

MEAL_LABELS = {
    "BB": "BB - Bed & Breakfast",
    "HB": "HB - Half board (breakfast + dinner)",
    "FB": "FB - Full board (all meals)",
    "SC": "SC - Self catering / no meal package",
}
SEGMENT_HELP = "How the booking was sold (e.g. Online TA = online travel agency)."
RISK_COLORS = {"Low": "#2a9d8f", "Medium": "#f4a261", "High": "#e63946"}
FEATURE_LABELS = {
    "lead_time": "Lead time", "deposit_type": "Deposit type", "country": "Country",
    "market_segment": "Market segment", "adr": "Average daily rate",
    "total_of_special_requests": "Special requests", "previous_cancellations": "Previous cancellations",
    "required_car_parking_spaces": "Parking spaces", "customer_type": "Customer type",
    "hotel": "Hotel type", "stays_in_week_nights": "Week nights", "stays_in_weekend_nights": "Weekend nights",
    "adults": "Adults", "children": "Children", "meal": "Meal type",
    "distribution_channel": "Distribution channel", "is_repeated_guest": "Repeated guest",
}


# --------------------------------------------------------------------------
# Cached loaders
# --------------------------------------------------------------------------
@st.cache_resource(show_spinner="Loading model...")
def get_model():
    return load_model()


@st.cache_data(show_spinner=False)
def get_metadata() -> dict:
    return load_metadata()


def load_assets():
    """Load model + metadata, or show a friendly message and stop the app."""
    try:
        return get_model(), get_metadata()
    except FileNotFoundError as exc:
        st.error("The trained model is not available yet.")
        st.code(str(exc))
        st.info("Place `hotel_bookings.csv` in the `data/` folder and run "
                "`python -m src.train` to create the model files.")
        st.stop()


# --------------------------------------------------------------------------
# Page: Home
# --------------------------------------------------------------------------
def page_home(meta: dict) -> None:
    st.title("🏨 Hotel Booking Cancellation Prediction")
    st.markdown(
        "A machine-learning project that predicts whether a hotel booking will be "
        "**canceled** and estimates the **probability of cancellation**, so hotels "
        "can reduce the revenue they lose to empty rooms."
    )

    left, right = st.columns(2)
    with left:
        st.subheader("Project objectives")
        st.markdown(
            "- Analyse historical hotel bookings.\n"
            "- Identify the factors that influence cancellations.\n"
            "- Predict whether a new booking will be canceled.\n"
            "- Estimate the cancellation probability.\n"
            "- Provide practical insights to reduce financial losses."
        )
        st.subheader("How to use this app")
        st.markdown(
            "1. **Prediction** - fill in a booking and get a risk assessment.\n"
            "2. **Analytics Dashboard** - explore cancellation patterns and model quality."
        )
    with right:
        st.subheader("Dataset information")
        dash = meta["dashboard"]
        clean = meta["cleaning_report"]
        st.markdown(
            f"- **Source:** Hotel Booking Demand dataset (Kaggle) - one city hotel and one resort hotel in Portugal.\n"
            f"- **Raw bookings:** {dash['total_bookings_raw']:,} rows, 32 columns.\n"
            f"- **After cleaning:** {dash['total_bookings_clean']:,} bookings "
            f"({clean['duplicates_removed']:,} exact duplicates and a few invalid records removed).\n"
            f"- **Target:** `is_canceled` (0 = not canceled, 1 = canceled).\n"
            f"- **Cancellation rate (cleaned data):** {dash['cancel_rate_clean']:.1%}.\n"
            f"- **Final model:** {meta['best_algorithm']} (tuned with cross-validation)."
        )
    st.info("Data leakage was avoided: columns such as `reservation_status` that reveal the "
            "outcome were removed, and all preprocessing is fitted on the training data only.")


# --------------------------------------------------------------------------
# Page: Prediction
# --------------------------------------------------------------------------
def risk_bar(probability: float, threshold: float, level: str) -> None:
    """Coloured horizontal bar showing the probability and the decision threshold."""
    color = RISK_COLORS[level]
    st.markdown(
        f"""
        <div style="position:relative;background:#e9ecef;border-radius:10px;height:28px;margin:8px 0 4px 0;">
          <div style="width:{probability * 100:.1f}%;background:{color};height:28px;border-radius:10px;"></div>
          <div style="position:absolute;left:{threshold * 100:.1f}%;top:-4px;height:36px;
                      border-left:3px dashed #343a40;"></div>
        </div>
        <div style="font-size:0.8rem;color:#6c757d;">0% &nbsp;&nbsp;|&nbsp;&nbsp; dashed line =
        decision threshold ({threshold:.0%}) &nbsp;&nbsp;|&nbsp;&nbsp; 100%</div>
        """,
        unsafe_allow_html=True,
    )


def page_prediction(model, meta: dict) -> None:
    st.title("🔮 Booking Cancellation Prediction")
    st.write("Enter the booking details and press **Predict**.")
    opts = meta["category_options"]
    threshold = float(meta["threshold"])

    with st.form("booking_form"):
        c1, c2, c3 = st.columns(3)
        with c1:
            hotel = st.selectbox("Hotel type", opts["hotel"])
            lead_time = st.number_input("Lead time (days between booking and arrival)",
                                        min_value=0, max_value=737, value=60, step=1)
            adults = st.number_input("Number of adults", min_value=0, max_value=10, value=2, step=1)
            children = st.number_input("Number of children", min_value=0, max_value=10, value=0, step=1)
            weekend = st.number_input("Weekend nights (Sat/Sun)", min_value=0, max_value=19, value=1, step=1)
            week = st.number_input("Week nights (Mon-Fri)", min_value=0, max_value=50, value=2, step=1)
        with c2:
            meal_opts = [m for m in opts["meal"] if m in MEAL_LABELS]
            meal = st.selectbox("Meal type", meal_opts, format_func=lambda m: MEAL_LABELS.get(m, m))
            countries = opts["country"]
            country = st.selectbox("Country (ISO code of the guest)", countries,
                                   index=countries.index("PRT") if "PRT" in countries else 0)
            market_segment = st.selectbox("Market segment", opts["market_segment"], help=SEGMENT_HELP)
            channels = [c for c in opts["distribution_channel"] if c != "Undefined"]
            distribution_channel = st.selectbox("Distribution channel", channels)
            repeated = st.selectbox("Is repeated guest?", ["No", "Yes"])
            prev_cancel = st.number_input("Previous cancellations", min_value=0, max_value=26, value=0, step=1)
        with c3:
            deposit_type = st.selectbox("Deposit type", opts["deposit_type"],
                                        help="No Deposit, Non Refund (deposit paid, not refundable) or Refundable.")
            customer_type = st.selectbox("Customer type", opts["customer_type"])
            adr = st.number_input("Average daily rate (ADR, per room per night)",
                                  min_value=0.0, max_value=1000.0, value=100.0, step=1.0)
            parking = 0
            if cfg.USE_PARKING_FEATURE:
                parking = st.number_input("Required car parking spaces", min_value=0, max_value=8, value=0, step=1)
            requests = st.number_input("Total special requests", min_value=0, max_value=5, value=0, step=1)
            if not cfg.USE_PARKING_FEATURE:
                st.caption("Car parking requests are not used: in this dataset no booking with a "
                           "parking space was ever canceled, so the field looks like it is filled in "
                           "only after the stay (data leakage).")
        submitted = st.form_submit_button("Predict")

    if not submitted:
        return

    booking = {
        "hotel": hotel, "lead_time": lead_time, "adults": adults, "children": children,
        "stays_in_weekend_nights": weekend, "stays_in_week_nights": week, "meal": meal,
        "country": country, "market_segment": market_segment,
        "distribution_channel": distribution_channel,
        "is_repeated_guest": 1 if repeated == "Yes" else 0,
        "previous_cancellations": prev_cancel, "deposit_type": deposit_type,
        "customer_type": customer_type, "adr": adr,
        "total_of_special_requests": requests,
    }
    if cfg.USE_PARKING_FEATURE:
        booking["required_car_parking_spaces"] = parking

    problems = validate_booking(booking)
    if problems:
        for p in problems:
            st.error(p)
        return
    try:
        pred = predict_booking(model, booking, threshold)
    except Exception as exc:  # noqa: BLE001 - show any problem to the user
        st.error(f"Prediction failed: {exc}")
        return

    st.divider()
    st.subheader("Result")
    col_a, col_b, col_c = st.columns(3)
    col_a.metric("Prediction", "Canceled" if pred.is_canceled else "Not Canceled")
    col_b.metric("Cancellation probability", f"{pred.probability:.1%}")
    col_c.metric("Risk level", pred.risk_level)

    risk_bar(pred.probability, threshold, pred.risk_level)
    color = RISK_COLORS[pred.risk_level]
    st.markdown(
        f"<h4 style='color:{color};'>{pred.risk_level} cancellation risk</h4>",
        unsafe_allow_html=True,
    )

    st.subheader("Recommendation for hotel management")
    for tip in recommendation(pred, booking):
        st.markdown(f"- {tip}")

    with st.expander("Booking data sent to the model"):
        st.dataframe(build_input_frame(booking))
    st.caption("The probability comes from a statistical model trained on historical bookings. "
               "It supports decisions but cannot guarantee what an individual guest will do.")


# --------------------------------------------------------------------------
# Page: Analytics Dashboard
# --------------------------------------------------------------------------
def rate_chart(records: list[dict], col: str, title: str, sort_x: bool = False) -> alt.Chart:
    df = pd.DataFrame(records)
    x = alt.X(f"{col}:N", title=None, sort=None if sort_x else "-y")
    return (
        alt.Chart(df, title=title)
        .mark_bar(color="#264653")
        .encode(
            x=x,
            y=alt.Y("cancel_rate:Q", title="Cancellation rate", axis=alt.Axis(format="%")),
            tooltip=[alt.Tooltip(f"{col}:N", title="Group"),
                     alt.Tooltip("bookings:Q", title="Bookings", format=","),
                     alt.Tooltip("cancel_rate:Q", title="Cancellation rate", format=".1%")],
        )
        .properties(height=320)
    )


def page_dashboard(meta: dict) -> None:
    st.title("📊 Analytics Dashboard")
    dash = meta["dashboard"]
    tm = meta["test_metrics_final"]

    # ---- headline numbers --------------------------------------------------
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Total bookings (raw)", f"{dash['total_bookings_raw']:,}")
    k2.metric("Bookings after cleaning", f"{dash['total_bookings_clean']:,}")
    k3.metric("Cancellation % (raw)", f"{dash['cancel_rate_raw']:.1%}")
    k4.metric("Cancellation % (cleaned)", f"{dash['cancel_rate_clean']:.1%}")
    st.caption("Raw data contains many exact duplicate rows; the model is trained on the cleaned data.")

    tab_dist, tab_factors, tab_model = st.tabs(
        ["Cancellation distribution", "Important cancellation factors", "Model performance"])

    # ---- tab 1: distribution -----------------------------------------------
    with tab_dist:
        dist = pd.DataFrame({
            "status": ["Not Canceled", "Canceled"],
            "bookings": [dash["not_canceled_clean"], dash["canceled_clean"]],
        })
        dist["share"] = dist["bookings"] / dist["bookings"].sum()
        donut = (
            alt.Chart(dist, title="Cancellation distribution (cleaned data)")
            .mark_arc(innerRadius=70)
            .encode(
                theta="bookings:Q",
                color=alt.Color("status:N", scale=alt.Scale(
                    domain=["Not Canceled", "Canceled"], range=["#2a9d8f", "#e76f51"]), title=None),
                tooltip=["status:N", alt.Tooltip("bookings:Q", format=","),
                         alt.Tooltip("share:Q", format=".1%")],
            )
            .properties(height=320)
        )
        c1, c2 = st.columns(2)
        c1.altair_chart(donut)
        hotel = rate_chart(dash["by_hotel"], "hotel", "Cancellation rate by hotel type")
        c2.altair_chart(hotel)

    # ---- tab 2: factors -----------------------------------------------------
    with tab_factors:
        st.markdown("**Explore how the cancellation rate changes across booking characteristics.**")
        dims = {
            "Deposit type": ("by_deposit_type", "deposit_type", False),
            "Market segment": ("by_market_segment", "market_segment", False),
            "Customer type": ("by_customer_type", "customer_type", False),
            "Distribution channel": ("by_distribution_channel", "distribution_channel", False),
            "Lead time": ("by_lead_time", "lead_time_group", True),
            "Average daily rate": ("by_adr", "adr_group", True),
            "Previous cancellations": ("by_previous_cancellation", "prev_cancel_group", False),
            "Country (top 10 by bookings)": ("by_country_top10", "country", False),
        }
        choice = st.selectbox("Choose a characteristic", list(dims))
        key, col, ordered = dims[choice]
        st.altair_chart(rate_chart(dash[key], col, f"Cancellation rate by {choice.lower()}", ordered))
        st.dataframe(pd.DataFrame(dash[key]).assign(
            cancel_rate=lambda d: (d["cancel_rate"] * 100).round(1).astype(str) + " %"))

        st.markdown("**What the model relies on most (permutation importance)**")
        perm = pd.DataFrame(meta["permutation_importance"]).head(12)
        perm["label"] = perm["feature"].map(FEATURE_LABELS).fillna(perm["feature"])
        imp = (
            alt.Chart(perm, title="Drop in ROC-AUC when the feature is shuffled (test set)")
            .mark_bar(color="#e76f51")
            .encode(
                x=alt.X("importance_mean:Q", title="Importance"),
                y=alt.Y("label:N", sort="-x", title=None),
                tooltip=[alt.Tooltip("label:N", title="Feature"),
                         alt.Tooltip("importance_mean:Q", format=".4f", title="Importance")],
            )
            .properties(height=360)
        )
        st.altair_chart(imp)

    # ---- tab 3: model performance ------------------------------------------
    with tab_model:
        st.markdown(f"**Final model:** {meta['best_algorithm']} - decision threshold "
                    f"**{meta['threshold']:.2f}** (chosen on training data only). "
                    f"All numbers below come from the untouched test set "
                    f"({meta['n_test']:,} bookings).")
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Accuracy", f"{tm['accuracy']:.3f}")
        m2.metric("Precision", f"{tm['precision']:.3f}")
        m3.metric("Recall", f"{tm['recall']:.3f}")
        m4.metric("F1-score", f"{tm['f1']:.3f}")
        m5.metric("ROC-AUC", f"{tm['roc_auc']:.3f}")

        c1, c2 = st.columns(2)
        roc = pd.DataFrame(meta["roc_curve"])
        roc_chart = (
            alt.Chart(roc, title="ROC curve (test set)").mark_line(color="#264653", strokeWidth=3)
            .encode(x=alt.X("fpr:Q", title="False positive rate"),
                    y=alt.Y("tpr:Q", title="True positive rate (recall)"))
            .properties(height=320)
        )
        diag = alt.Chart(pd.DataFrame({"x": [0, 1], "y": [0, 1]})).mark_line(
            strokeDash=[5, 5], color="gray").encode(x="x:Q", y="y:Q")
        c1.altair_chart(roc_chart + diag)

        cm = pd.DataFrame([
            {"Actual": "Not Canceled", "Predicted": "Not Canceled", "count": tm["tn"]},
            {"Actual": "Not Canceled", "Predicted": "Canceled", "count": tm["fp"]},
            {"Actual": "Canceled", "Predicted": "Not Canceled", "count": tm["fn"]},
            {"Actual": "Canceled", "Predicted": "Canceled", "count": tm["tp"]},
        ])
        base = alt.Chart(cm, title="Confusion matrix (test set)").encode(
            x=alt.X("Predicted:N", sort=["Not Canceled", "Canceled"]),
            y=alt.Y("Actual:N", sort=["Not Canceled", "Canceled"]))
        heat = base.mark_rect().encode(color=alt.Color("count:Q", scale=alt.Scale(scheme="blues"), legend=None))
        text = base.mark_text(fontSize=18).encode(text=alt.Text("count:Q", format=","))
        c2.altair_chart((heat + text).properties(height=320))

        st.markdown("**Threshold analysis** - moving the threshold trades precision for recall.")
        thr = pd.DataFrame(meta["threshold_table"])[["threshold", "precision", "recall", "f1"]]
        thr_long = thr.melt("threshold", var_name="metric", value_name="score")
        thr_chart = (
            alt.Chart(thr_long).mark_line(strokeWidth=3)
            .encode(x=alt.X("threshold:Q", title="Decision threshold"),
                    y=alt.Y("score:Q", title="Score (training out-of-fold)"),
                    color="metric:N",
                    tooltip=["metric:N", "threshold:Q", alt.Tooltip("score:Q", format=".3f")])
            .properties(height=300)
        )
        rule = alt.Chart(pd.DataFrame({"t": [meta["threshold"]]})).mark_rule(
            strokeDash=[6, 4], color="gray").encode(x="t:Q")
        st.altair_chart(thr_chart + rule)

        st.markdown("**Model comparison** (5-fold cross-validation on the training data)")
        comp = pd.DataFrame(meta["model_comparison"])
        show = comp[["model", "cv_roc_auc_mean", "cv_f1_mean", "cv_precision_mean", "cv_recall_mean",
                     "test_roc_auc", "test_f1"]].rename(columns={
            "model": "Model", "cv_roc_auc_mean": "CV ROC-AUC", "cv_f1_mean": "CV F1",
            "cv_precision_mean": "CV Precision", "cv_recall_mean": "CV Recall",
            "test_roc_auc": "Test ROC-AUC (thr 0.5)", "test_f1": "Test F1 (thr 0.5)"})
        st.dataframe(show.round(4), hide_index=True)


# --------------------------------------------------------------------------
# Main: sidebar navigation
# --------------------------------------------------------------------------
def main() -> None:
    model, meta = load_assets()
    st.sidebar.title("🏨 Navigation")
    page = st.sidebar.radio("Go to", ["Home", "Prediction", "Analytics Dashboard"])
    st.sidebar.markdown("---")
    st.sidebar.caption(f"Model: {meta['best_algorithm']}")
    if page == "Home":
        page_home(meta)
    elif page == "Prediction":
        page_prediction(model, meta)
    else:
        page_dashboard(meta)


if __name__ == "__main__":
    main()
