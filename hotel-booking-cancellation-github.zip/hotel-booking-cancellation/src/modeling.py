"""Model definitions, hyper-parameter search spaces and evaluation helpers."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import randint, uniform
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, confusion_matrix, f1_score,
    precision_score, recall_score, roc_auc_score,
)
from sklearn.tree import DecisionTreeClassifier

from . import config as cfg
from .features import make_pipeline

SEED = cfg.RANDOM_STATE


def get_models() -> dict:
    """Return {name: (untrained pipeline)} for the baseline and the 4 algorithms.

    Logistic Regression gets scaled numeric features; the tree-based models do
    not need scaling.
    """
    return {
        "Baseline (Majority Class)": make_pipeline(DummyClassifier(strategy="prior")),
        "Logistic Regression": make_pipeline(
            LogisticRegression(max_iter=2000, random_state=SEED), scale_numeric=True
        ),
        "Decision Tree": make_pipeline(
            DecisionTreeClassifier(max_depth=8, min_samples_leaf=20, random_state=SEED)
        ),
        "Random Forest": make_pipeline(
            RandomForestClassifier(
                n_estimators=100, min_samples_leaf=3, max_features="sqrt",
                n_jobs=-1, random_state=SEED,
            )
        ),
        "Gradient Boosting": make_pipeline(
            GradientBoostingClassifier(n_estimators=150, random_state=SEED)
        ),
    }


def get_param_distributions(model_name: str) -> dict:
    """Hyper-parameter search space for RandomizedSearchCV (keys use `model__`)."""
    spaces = {
        "Logistic Regression": {
            "model__C": [0.01, 0.1, 1, 10, 100],
        },
        "Decision Tree": {
            "model__max_depth": randint(5, 25),
            "model__min_samples_leaf": randint(5, 80),
            "model__criterion": ["gini", "entropy"],
        },
        "Random Forest": {
            "model__n_estimators": [100, 150, 200],
            "model__max_depth": [12, 18, 25, None],
            "model__min_samples_leaf": [2, 3, 5, 10],
            "model__max_features": ["sqrt", 0.3, 0.5],
        },
        "Gradient Boosting": {
            "model__n_estimators": [100, 200, 300],
            "model__learning_rate": [0.05, 0.1, 0.2],
            "model__max_depth": [3, 4, 5, 6],
            "model__subsample": [0.7, 0.85, 1.0],
            "model__min_samples_leaf": [1, 10, 30],
        },
    }
    return spaces[model_name]


# ---------------------------------------------------------------------------
# Evaluation helpers
# ---------------------------------------------------------------------------
def metrics_at_threshold(y_true, proba, threshold: float = 0.5) -> dict:
    """All headline metrics for a given probability threshold."""
    y_pred = (np.asarray(proba) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    return {
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, proba)),
        "pr_auc": float(average_precision_score(y_true, proba)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def threshold_table(y_true, proba, thresholds=None) -> pd.DataFrame:
    """Precision / recall / F1 for many thresholds (used for threshold analysis)."""
    if thresholds is None:
        thresholds = np.round(np.arange(0.10, 0.91, 0.01), 2)
    rows = []
    for t in thresholds:
        m = metrics_at_threshold(y_true, proba, t)
        rows.append({k: m[k] for k in
                     ["threshold", "accuracy", "precision", "recall", "f1", "tn", "fp", "fn", "tp"]})
    return pd.DataFrame(rows)


def best_f1_threshold(table: pd.DataFrame) -> float:
    """Threshold with the highest F1 (ties -> the one closest to 0.5)."""
    best = table[table["f1"] == table["f1"].max()].copy()
    best["dist"] = (best["threshold"] - 0.5).abs()
    return float(best.sort_values("dist").iloc[0]["threshold"])
